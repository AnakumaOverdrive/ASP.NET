﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Esint.CodeBuilder.BLL;

namespace CodeBuilderReg
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (textBox1.Text.Trim()=="")
            {
                MessageBox.Show("请输入机器码!");
            }
            try
            {
               Int64 MCode =  Convert.ToInt64(textBox1.Text);
               MCode = MCode * 3 + 2011;
               textBox2.Text = SecurityBLL.getMd5Hash(MCode.ToString()).ToUpper();

            }
            catch (System.Exception ex)
            {
                MessageBox.Show("输入错误!");

            }
        }
    }
}
