﻿using System;
namespace Esint.CodeBuilder.InterFace
{
   public  interface IForeignKeyColumn
    {
        string FKColumnName { get; set; }
        string FKTableName { get; set; }
        string PKColumnName { get; set; }
        string PKTableName { get; set; }
    }
}
