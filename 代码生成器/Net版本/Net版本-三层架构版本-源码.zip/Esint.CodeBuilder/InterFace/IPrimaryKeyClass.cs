﻿using System;
namespace Esint.CodeBuilder.InterFace
{
    public interface IPrimaryKeyClass
    {
        /// <summary>
        /// 字段列表
        /// </summary>
        System.Collections.Generic.List<IColumn> Columns { get; set; }

        /// <summary>
        /// 主键 名称
        /// </summary>
        string PrimaryKeyName { get; set; }

        /// <summary>
        /// 表名
        /// </summary>
        string TableName { get; set; }
    }
}
