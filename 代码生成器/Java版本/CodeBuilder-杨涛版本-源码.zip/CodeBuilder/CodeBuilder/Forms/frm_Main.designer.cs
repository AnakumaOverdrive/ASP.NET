﻿namespace Esint.CodeBuilder.Forms
{
    partial class frm_Main
    {
        /// <summary>
        /// 必需的设计器变量。

        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。

        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。

        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frm_Main));
            this.stat_Bottom = new System.Windows.Forms.StatusStrip();
            this.popMenu_Template = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.menu_Main = new System.Windows.Forms.MenuStrip();
            this.文件ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.打开ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.设置ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.mi_SetConnect = new System.Windows.Forms.ToolStripMenuItem();
            this.设置模板ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.数据类型转换设置ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator3 = new System.Windows.Forms.ToolStripSeparator();
            this.tsm_SysConfig = new System.Windows.Forms.ToolStripMenuItem();
            this.tsm_Builder = new System.Windows.Forms.ToolStripMenuItem();
            this.帮助ToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.帮助F1ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.splitContainer1 = new System.Windows.Forms.SplitContainer();
            this.panel2 = new System.Windows.Forms.Panel();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.tv_Tree = new System.Windows.Forms.TreeView();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.treeView1 = new System.Windows.Forms.TreeView();
            this.imglist_DataBase = new System.Windows.Forms.ImageList(this.components);
            this.panel1 = new System.Windows.Forms.Panel();
            this.webBrowser1 = new System.Windows.Forms.WebBrowser();
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.tsl_FileName = new System.Windows.Forms.ToolStripLabel();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.tsbtn_Save = new System.Windows.Forms.ToolStripButton();
            this.tsbtn_SaveAll = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.tsbtn_Copy = new System.Windows.Forms.ToolStripButton();
            this.tscb_FileList = new System.Windows.Forms.ToolStripComboBox();
            this.txtEdit_Code = new ICSharpCode.TextEditor.TextEditorControl();
            this.menu_Main.SuspendLayout();
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.Panel2.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.panel1.SuspendLayout();
            this.toolStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // stat_Bottom
            // 
            this.stat_Bottom.Location = new System.Drawing.Point(0, 580);
            this.stat_Bottom.Name = "stat_Bottom";
            this.stat_Bottom.Size = new System.Drawing.Size(855, 22);
            this.stat_Bottom.TabIndex = 0;
            this.stat_Bottom.Text = "statusStrip1";
            // 
            // popMenu_Template
            // 
            this.popMenu_Template.Name = "contextMenuStrip1";
            this.popMenu_Template.Size = new System.Drawing.Size(61, 4);
            // 
            // menu_Main
            // 
            this.menu_Main.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.文件ToolStripMenuItem,
            this.设置ToolStripMenuItem,
            this.tsm_Builder,
            this.帮助ToolStripMenuItem1});
            this.menu_Main.Location = new System.Drawing.Point(0, 0);
            this.menu_Main.Name = "menu_Main";
            this.menu_Main.Size = new System.Drawing.Size(855, 25);
            this.menu_Main.TabIndex = 4;
            this.menu_Main.Text = "menuStrip2";
            // 
            // 文件ToolStripMenuItem
            // 
            this.文件ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.打开ToolStripMenuItem});
            this.文件ToolStripMenuItem.Name = "文件ToolStripMenuItem";
            this.文件ToolStripMenuItem.ShortcutKeyDisplayString = "";
            this.文件ToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Alt | System.Windows.Forms.Keys.F)));
            this.文件ToolStripMenuItem.Size = new System.Drawing.Size(58, 21);
            this.文件ToolStripMenuItem.Text = "文件(&F)";
            // 
            // 打开ToolStripMenuItem
            // 
            this.打开ToolStripMenuItem.Name = "打开ToolStripMenuItem";
            this.打开ToolStripMenuItem.Size = new System.Drawing.Size(100, 22);
            this.打开ToolStripMenuItem.Text = "打开";
            // 
            // 设置ToolStripMenuItem
            // 
            this.设置ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mi_SetConnect,
            this.设置模板ToolStripMenuItem,
            this.数据类型转换设置ToolStripMenuItem,
            this.toolStripSeparator3,
            this.tsm_SysConfig});
            this.设置ToolStripMenuItem.Name = "设置ToolStripMenuItem";
            this.设置ToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Alt | System.Windows.Forms.Keys.S)));
            this.设置ToolStripMenuItem.Size = new System.Drawing.Size(59, 21);
            this.设置ToolStripMenuItem.Text = "设置(&S)";
            // 
            // mi_SetConnect
            // 
            this.mi_SetConnect.Name = "mi_SetConnect";
            this.mi_SetConnect.Size = new System.Drawing.Size(172, 22);
            this.mi_SetConnect.Text = "设置连接...";
            this.mi_SetConnect.Click += new System.EventHandler(this.mi_SetConnect_Click);
            // 
            // 设置模板ToolStripMenuItem
            // 
            this.设置模板ToolStripMenuItem.Name = "设置模板ToolStripMenuItem";
            this.设置模板ToolStripMenuItem.Size = new System.Drawing.Size(172, 22);
            this.设置模板ToolStripMenuItem.Text = "设置模板";
            // 
            // 数据类型转换设置ToolStripMenuItem
            // 
            this.数据类型转换设置ToolStripMenuItem.Name = "数据类型转换设置ToolStripMenuItem";
            this.数据类型转换设置ToolStripMenuItem.Size = new System.Drawing.Size(172, 22);
            this.数据类型转换设置ToolStripMenuItem.Text = "数据类型转换设置";
            // 
            // toolStripSeparator3
            // 
            this.toolStripSeparator3.Name = "toolStripSeparator3";
            this.toolStripSeparator3.Size = new System.Drawing.Size(169, 6);
            // 
            // tsm_SysConfig
            // 
            this.tsm_SysConfig.Name = "tsm_SysConfig";
            this.tsm_SysConfig.Size = new System.Drawing.Size(172, 22);
            this.tsm_SysConfig.Text = "系统选项...";
            this.tsm_SysConfig.Click += new System.EventHandler(this.tsm_SysConfig_Click);
            // 
            // tsm_Builder
            // 
            this.tsm_Builder.Name = "tsm_Builder";
            this.tsm_Builder.Size = new System.Drawing.Size(84, 21);
            this.tsm_Builder.Text = "批量生成(&B)";
            // 
            // 帮助ToolStripMenuItem1
            // 
            this.帮助ToolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.帮助F1ToolStripMenuItem});
            this.帮助ToolStripMenuItem1.Name = "帮助ToolStripMenuItem1";
            this.帮助ToolStripMenuItem1.Size = new System.Drawing.Size(61, 21);
            this.帮助ToolStripMenuItem1.Text = "帮助(&H)";
            // 
            // 帮助F1ToolStripMenuItem
            // 
            this.帮助F1ToolStripMenuItem.Name = "帮助F1ToolStripMenuItem";
            this.帮助F1ToolStripMenuItem.ShortcutKeys = System.Windows.Forms.Keys.F1;
            this.帮助F1ToolStripMenuItem.Size = new System.Drawing.Size(121, 22);
            this.帮助F1ToolStripMenuItem.Text = "帮助";
            this.帮助F1ToolStripMenuItem.Click += new System.EventHandler(this.帮助F1ToolStripMenuItem_Click);
            // 
            // splitContainer1
            // 
            this.splitContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer1.Location = new System.Drawing.Point(0, 25);
            this.splitContainer1.Name = "splitContainer1";
            // 
            // splitContainer1.Panel1
            // 
            this.splitContainer1.Panel1.Controls.Add(this.panel2);
            // 
            // splitContainer1.Panel2
            // 
            this.splitContainer1.Panel2.BackColor = System.Drawing.SystemColors.ControlDark;
            this.splitContainer1.Panel2.Controls.Add(this.panel1);
            this.splitContainer1.Panel2.Controls.Add(this.toolStrip1);
            this.splitContainer1.Panel2.Controls.Add(this.txtEdit_Code);
            this.splitContainer1.Size = new System.Drawing.Size(855, 555);
            this.splitContainer1.SplitterDistance = 229;
            this.splitContainer1.TabIndex = 5;
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.tabControl1);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel2.Location = new System.Drawing.Point(0, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(229, 555);
            this.panel2.TabIndex = 3;
            // 
            // tabControl1
            // 
            this.tabControl1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Location = new System.Drawing.Point(0, 0);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(226, 555);
            this.tabControl1.TabIndex = 2;
            this.tabControl1.SelectedIndexChanged += new System.EventHandler(this.tabControl1_SelectedIndexChanged);
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.tv_Tree);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(218, 529);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "数据库";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // tv_Tree
            // 
            this.tv_Tree.CheckBoxes = true;
            this.tv_Tree.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tv_Tree.Location = new System.Drawing.Point(3, 3);
            this.tv_Tree.Name = "tv_Tree";
            this.tv_Tree.Size = new System.Drawing.Size(212, 523);
            this.tv_Tree.TabIndex = 2;
            this.tv_Tree.MouseDown += new System.Windows.Forms.MouseEventHandler(this.tv_Tree_MouseDown);
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.treeView1);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(218, 530);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "代码资源";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // treeView1
            // 
            this.treeView1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.treeView1.ImageIndex = 2;
            this.treeView1.ImageList = this.imglist_DataBase;
            this.treeView1.Location = new System.Drawing.Point(3, 3);
            this.treeView1.Name = "treeView1";
            this.treeView1.SelectedImageIndex = 0;
            this.treeView1.Size = new System.Drawing.Size(215, 524);
            this.treeView1.TabIndex = 1;
            this.treeView1.NodeMouseClick += new System.Windows.Forms.TreeNodeMouseClickEventHandler(this.treeView1_NodeMouseClick);
            // 
            // imglist_DataBase
            // 
            this.imglist_DataBase.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imglist_DataBase.ImageStream")));
            this.imglist_DataBase.TransparentColor = System.Drawing.Color.Transparent;
            this.imglist_DataBase.Images.SetKeyName(0, "t.gif");
            this.imglist_DataBase.Images.SetKeyName(1, "v.gif");
            this.imglist_DataBase.Images.SetKeyName(2, "f.gif");
            this.imglist_DataBase.Images.SetKeyName(3, "db.gif");
            this.imglist_DataBase.Images.SetKeyName(4, "Layered_Folders_010.png");
            this.imglist_DataBase.Images.SetKeyName(5, "21(1).png");
            // 
            // panel1
            // 
            this.panel1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel1.Controls.Add(this.webBrowser1);
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(622, 555);
            this.panel1.TabIndex = 2;
            // 
            // webBrowser1
            // 
            this.webBrowser1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.webBrowser1.Location = new System.Drawing.Point(0, 0);
            this.webBrowser1.MinimumSize = new System.Drawing.Size(20, 20);
            this.webBrowser1.Name = "webBrowser1";
            this.webBrowser1.Size = new System.Drawing.Size(622, 555);
            this.webBrowser1.TabIndex = 0;
            this.webBrowser1.Url = new System.Uri("", System.UriKind.Relative);
            this.webBrowser1.DocumentCompleted += new System.Windows.Forms.WebBrowserDocumentCompletedEventHandler(this.webBrowser1_DocumentCompleted);
            // 
            // toolStrip1
            // 
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsl_FileName,
            this.toolStripSeparator1,
            this.tsbtn_Save,
            this.tsbtn_SaveAll,
            this.toolStripSeparator2,
            this.tsbtn_Copy,
            this.tscb_FileList});
            this.toolStrip1.Location = new System.Drawing.Point(0, 0);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Size = new System.Drawing.Size(622, 25);
            this.toolStrip1.TabIndex = 1;
            this.toolStrip1.Text = "toolStrip1";
            // 
            // tsl_FileName
            // 
            this.tsl_FileName.Name = "tsl_FileName";
            this.tsl_FileName.Size = new System.Drawing.Size(0, 22);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(6, 25);
            // 
            // tsbtn_Save
            // 
            this.tsbtn_Save.Image = ((System.Drawing.Image)(resources.GetObject("tsbtn_Save.Image")));
            this.tsbtn_Save.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbtn_Save.Name = "tsbtn_Save";
            this.tsbtn_Save.Size = new System.Drawing.Size(76, 22);
            this.tsbtn_Save.Text = "保存当前";
            this.tsbtn_Save.Click += new System.EventHandler(this.tsbtn_Save_Click);
            // 
            // tsbtn_SaveAll
            // 
            this.tsbtn_SaveAll.Image = ((System.Drawing.Image)(resources.GetObject("tsbtn_SaveAll.Image")));
            this.tsbtn_SaveAll.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbtn_SaveAll.Name = "tsbtn_SaveAll";
            this.tsbtn_SaveAll.Size = new System.Drawing.Size(76, 22);
            this.tsbtn_SaveAll.Text = "保存全部";
            this.tsbtn_SaveAll.Click += new System.EventHandler(this.tsbtn_SaveAll_Click);
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(6, 25);
            // 
            // tsbtn_Copy
            // 
            this.tsbtn_Copy.Image = ((System.Drawing.Image)(resources.GetObject("tsbtn_Copy.Image")));
            this.tsbtn_Copy.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbtn_Copy.Name = "tsbtn_Copy";
            this.tsbtn_Copy.Size = new System.Drawing.Size(52, 22);
            this.tsbtn_Copy.Text = "复制";
            this.tsbtn_Copy.Click += new System.EventHandler(this.tsbtn_Copy_Click);
            // 
            // tscb_FileList
            // 
            this.tscb_FileList.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.tscb_FileList.DropDownWidth = 240;
            this.tscb_FileList.Name = "tscb_FileList";
            this.tscb_FileList.Size = new System.Drawing.Size(250, 25);
            this.tscb_FileList.SelectedIndexChanged += new System.EventHandler(this.tscb_FileList_SelectedIndexChanged);
            // 
            // txtEdit_Code
            // 
            this.txtEdit_Code.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtEdit_Code.AutoScroll = true;
            this.txtEdit_Code.IsReadOnly = false;
            this.txtEdit_Code.LineViewerStyle = ICSharpCode.TextEditor.Document.LineViewerStyle.FullRow;
            this.txtEdit_Code.Location = new System.Drawing.Point(0, 26);
            this.txtEdit_Code.Name = "txtEdit_Code";
            this.txtEdit_Code.ShowTabs = true;
            this.txtEdit_Code.Size = new System.Drawing.Size(622, 528);
            this.txtEdit_Code.TabIndex = 0;
            this.txtEdit_Code.TextRenderingHint = System.Drawing.Text.TextRenderingHint.ClearTypeGridFit;
            this.txtEdit_Code.VRulerRow = 0;
            this.txtEdit_Code.Load += new System.EventHandler(this.txtEdit_Code_Load);
            // 
            // frm_Main
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(855, 602);
            this.Controls.Add(this.splitContainer1);
            this.Controls.Add(this.stat_Bottom);
            this.Controls.Add(this.menu_Main);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "frm_Main";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Esint代码生成工具";
            this.menu_Main.ResumeLayout(false);
            this.menu_Main.PerformLayout();
            this.splitContainer1.Panel1.ResumeLayout(false);
            this.splitContainer1.Panel2.ResumeLayout(false);
            this.splitContainer1.Panel2.PerformLayout();
            this.splitContainer1.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage2.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.StatusStrip stat_Bottom;
        private System.Windows.Forms.ContextMenuStrip popMenu_Template;
        private System.Windows.Forms.MenuStrip menu_Main;
        private System.Windows.Forms.ToolStripMenuItem 文件ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 打开ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 设置ToolStripMenuItem;
        private System.Windows.Forms.SplitContainer splitContainer1;
        private System.Windows.Forms.ImageList imglist_DataBase;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.ToolStripMenuItem mi_SetConnect;
        private System.Windows.Forms.ToolStripMenuItem 设置模板ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 数据类型转换设置ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem tsm_SysConfig;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator3;
        private System.Windows.Forms.ToolStripMenuItem 帮助ToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem tsm_Builder;
        private System.Windows.Forms.ToolStripMenuItem 帮助F1ToolStripMenuItem;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.TreeView tv_Tree;
        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.ToolStripLabel tsl_FileName;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripButton tsbtn_Save;
        private System.Windows.Forms.ToolStripButton tsbtn_SaveAll;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        private System.Windows.Forms.ToolStripButton tsbtn_Copy;
        private System.Windows.Forms.ToolStripComboBox tscb_FileList;
        private ICSharpCode.TextEditor.TextEditorControl txtEdit_Code;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.WebBrowser webBrowser1;
        private System.Windows.Forms.TreeView treeView1;
    }
}

