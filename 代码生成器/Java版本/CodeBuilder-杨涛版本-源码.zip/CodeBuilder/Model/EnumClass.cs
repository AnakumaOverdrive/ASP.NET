﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Esint.CodeBuilder.Model
{
    /// <summary>
    /// 数据库类型
    /// </summary>
    public enum DataBaseType
    {
        SqlServer,
        Oracle,
        MySql,
        NULL
    }
}
