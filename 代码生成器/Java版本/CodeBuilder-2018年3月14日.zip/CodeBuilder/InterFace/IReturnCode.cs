﻿using System;
namespace Esint.CodeBuilder.InterFace
{
    public interface IReturnCode
    {
        System.Text.StringBuilder CodeText { get; set; }
        string CodeType { get; set; }
        string FileName { get; set; }
        string FilePath { get; set; }
    }
}
