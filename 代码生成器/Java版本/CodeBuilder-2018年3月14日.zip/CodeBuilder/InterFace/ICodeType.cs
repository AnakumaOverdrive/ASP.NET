﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Esint.CodeBuilder.InterFace
{
    public interface ICodeType
    {
        string Flag { get; set; }
        string Meaning { get; set; }
    }
}
