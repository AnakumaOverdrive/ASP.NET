﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Esint.CodeBuilder.InterFace;
using Esint.TemplateCommon;

namespace Esint.Template.BLL
{
    public class BLL_JAVA33 : ITemplate
    {
        public IDbTable Tbl { get; set; }
        public string NameSpace { get; set; }
        public string FileName { get; set; }
        public string OperName { get; set; }
        public string ConnectString { get; set; }
        public ICodeBuilder DataAccess { get; set; }
        public List<IDbTable> Tbls { get; set; }
        public bool IsPackage { get; set; }


        public IReturnCode[] GetCode()
        {

            //============================================第一部分BLL.designer.cs(the first part)=================================
            StringBuilder sb = new StringBuilder();
            string pascalName = GetewPascalName();
            string lower = Lower();
            //sb.AppendLine("package com." + DataAccess.AppName + ".service;");
            //sb.AppendLine("import com.esint.common.service.BaseService;");
            //sb.AppendLine("import com." + DataAccess.AppName + ".pojo." + GetewPascalName() + ";");

            //2018-03-05 14:49 赵秀玲 修改实现类
           
            sb.AppendLine("package com." + DataAccess.AppName + ".service.impl;");
            sb.AppendLine("import java.util.ArrayList;");
            sb.AppendLine("import java.util.HashMap;");
            sb.AppendLine("import java.util.List;");
            sb.AppendLine("import java.util.Map;");

            sb.AppendLine("import org.springframework.beans.factory.annotation.Autowired;");
            sb.AppendLine("import org.springframework.beans.factory.annotation.Qualifier;");
            sb.AppendLine("import org.springframework.stereotype.Service;");

            sb.AppendLine("import com." + DataAccess.AppName + ".mapper." + GetewPascalName() + "Mapper;");
            sb.AppendLine("import com." + DataAccess.AppName + ".service." + GetewPascalName() + "Service;");



            //============================================第一部分Service.java(the first part)=================================


            //sb.AppendLine("/**");
            //sb.AppendLine("* " + GetewPascalName() + " 业务逻辑接口");
            //sb.AppendLine("*");
            //sb.AppendLine("* @author " + OperName + "");
            //sb.AppendLine("* ");
            //sb.AppendLine("*/");

            //sb.AppendLine("public interface " + GetewPascalName() + "Service extends BaseService<" + GetewPascalName() + ", " + GetPrimaryDataType() + "> {}");

            //==================================================End===========================================================

            //========================================第二部分BLL.cs开始(The second part)=============================
            



            sb.AppendLine("/**");
            sb.AppendLine(" * " + Tbl.TableName + " 业务逻辑实现类");
            sb.AppendLine(" * 文件说明: " + Tbl.TableDescription + "业务逻辑实现类");
            sb.AppendLine(" * 作    者: " + this.OperName);
            sb.AppendLine(" * 生成日期: " + DateTime.Now.ToString("yyyy年MM月dd日"));
            sb.AppendLine(" * 生成模板: Esint.Template.ServiceImpl.JAVA_ServiceImpl版");
            sb.AppendLine(" * 修改说明：");
            sb.AppendLine(" */");




          
            sb.AppendLine("@Service(\"" + Lower() + "Service\")");
            sb.AppendLine("public class " + GetewPascalName() + "ServiceImpl  implements");
            sb.AppendLine("" + GetewPascalName() + "Service {");
          

            sb.AppendLine("// 引用Service开始");
            sb.AppendLine("@Autowired");
            sb.AppendLine("@Qualifier(\"" + lower + "Mapper\")");

            sb.AppendLine("private " + pascalName + "Mapper " + lower + "Mapper;");

            sb.AppendLine("// 引用Service结束");

            sb.AppendLine("// 基础方法开始");
            


            sb.AppendLine("/**");
            sb.AppendLine("* 根据主键获取实体");
            sb.AppendLine("* ");
            sb.AppendLine("* @param pkID ");
            sb.AppendLine("* @return");
            sb.AppendLine("* @throws Exception");
            sb.AppendLine("*/");
            sb.AppendLine("public Map<String, Object> query" + pascalName + "(String pkID) throws Exception {");
            sb.AppendLine("return " + lower + "Mapper.selectByID(pkID);");
            sb.AppendLine("}");



            sb.AppendLine("/**");
            sb.AppendLine("* 根据条件获取数据列表-带分页列表");
            sb.AppendLine("* ");
            sb.AppendLine("* @return");
            sb.AppendLine("* @throws Exception");
            sb.AppendLine("*/");
            sb.AppendLine("public Map<String, Object> query" + pascalName + "PageList(Map<String, Object> params) throws Exception {");
            sb.AppendLine("Map<String, Object> result = new HashMap<String, Object>();");
            //拼接函数体-----------------------开始
            sb.AppendLine("params.put(\"isPage\", 1);");
            sb.AppendLine("int pages = Integer.parseInt(params.get(\"page\").toString());");
            sb.AppendLine("int rows = Integer.parseInt(params.get(\"row\").toString());");
            sb.AppendLine("int _begin = ((pages - 1) * rows) + 1;");
            sb.AppendLine("int _end = pages * rows;");
            sb.AppendLine("params.put(\"_begin\", _begin);");
            sb.AppendLine("params.put(\"_end\", _end);");
            sb.AppendLine("int rowcount = " + lower + "Mapper.selectCount(params);");
            sb.AppendLine("if (rowcount > 0) {");
            sb.AppendLine("result.put(\"total\", rowcount);");
            sb.AppendLine("result.put(\"data\", " + lower + "Mapper.select(params));");
            sb.AppendLine("}");
            sb.AppendLine("else {");
            sb.AppendLine("result.put(\"total\", 0);");
            sb.AppendLine("result.put(\"data\", new ArrayList<Map<String, Object>>());");
            sb.AppendLine("}");
           
            //拼接函数体-----------------------完毕

            sb.AppendLine("return result;");
            sb.AppendLine("}");


            sb.AppendLine("/**");
            sb.AppendLine("* 根据条件获取数据总量");
            sb.AppendLine("* ");
            sb.AppendLine("* @return");
            sb.AppendLine("* @throws Exception");
            sb.AppendLine("*/");
            sb.AppendLine("public int query" + pascalName + "Count(Map<String, Object> params) throws Exception {");
            sb.AppendLine("return " + lower + "Mapper.selectCount(params);");
            sb.AppendLine("}");



            sb.AppendLine("/**");
            sb.AppendLine("* 根据条件获取数据列表-不带分页列表");
            sb.AppendLine("* ");
            sb.AppendLine("* @return");
            sb.AppendLine("* @throws Exception");
            sb.AppendLine("*/");
            sb.AppendLine("public List<Map<String, Object>> query" + pascalName + "List(Map<String, Object> params) throws Exception {");
            sb.AppendLine("params.put(\"isPage\", 0);");
            sb.AppendLine("return " + lower + "Mapper.select(params);");
            sb.AppendLine("}");



            sb.AppendLine("/**");
            sb.AppendLine("* 根据获取数据插入对应数据表");
            sb.AppendLine("* ");
            sb.AppendLine("* @return");
            sb.AppendLine("* @throws Exception");
            sb.AppendLine("*/");
            sb.AppendLine("public int add" + pascalName + "(Map<String, Object> params) throws Exception {");
            sb.AppendLine("return " + lower + "Mapper.insert(params);");

            sb.AppendLine("}");




            sb.AppendLine("/**");
            sb.AppendLine("* 根据主键删除对应数据-物理删除");
            sb.AppendLine("* ");
            sb.AppendLine("* @return");
            sb.AppendLine("* @throws Exception");
            sb.AppendLine("*/");
            sb.AppendLine("public int del" + pascalName + "(String pkID) throws Exception {");
            sb.AppendLine("return " + lower + "Mapper.delete(pkID);");
            sb.AppendLine("}");




            sb.AppendLine("/**");
            sb.AppendLine("* 根据主键删除对应数据-物理删除-批量删除-主键之间使用半角逗号(,)做间隔符");
            sb.AppendLine("* ");
            sb.AppendLine("* @return");
            sb.AppendLine("* @throws Exception");
            sb.AppendLine("*/");
            sb.AppendLine("public int del" + pascalName + "List(String pkIDs) throws Exception {");
            //拼接函数体---------------开始
            sb.AppendLine("Map<String, Object> params = new HashMap<String, Object>();");
            sb.AppendLine("if (pkIDs != null && !\"\".equals(pkIDs)){");
            sb.AppendLine("String[] listparam = pkIDs.split(\", \");");
            sb.AppendLine("params.put(\"list\", listparam);");
            sb.AppendLine("return " + lower + "Mapper.deleteBatch(params);");
            sb.AppendLine("}");
            sb.AppendLine("else {");
            sb.AppendLine("return 0;");
            sb.AppendLine("}");
            sb.AppendLine("");
            //拼接函数体---------------结束
            sb.AppendLine("}");



            sb.AppendLine("/**");
            sb.AppendLine("* 根据获取数据修改对应数据表");
            sb.AppendLine("* ");
            sb.AppendLine("* @return");
            sb.AppendLine("* @throws Exception");
            sb.AppendLine("*/");
            sb.AppendLine("public int edit" + pascalName + "(Map<String, Object> params) throws Exception {");
            sb.AppendLine("return " + lower + "Mapper.update(params);");
            sb.AppendLine("}");




            sb.AppendLine("// 基础方法结束");


            sb.AppendLine("// 扩展方法 开始");
            sb.AppendLine("// 扩展方法 结束");

            sb.AppendLine("}");

         
            //===========================================End =========================================================

            ReturnCode[] returnCode = new ReturnCode[1];
            returnCode[0] = new ReturnCode();
            returnCode[0].FileName = String.Format(FileName + ".java", GetewPascalName());
            returnCode[0].CodeType = "C#";
            returnCode[0].CodeText = sb;
            return returnCode;


        }

        /// <summary>
        ///获取主键列方法
        /// </summary>
        /// <returns></returns>
        private string GetPrimaryParaList()
        {
            if (Tbl.PrimaryKey == null) return "";
            string returnstr = "";
            foreach (IColumn col in Tbl.PrimaryKey.Columns)
            {
                returnstr += col.DataType.CSharpType + " " + col.CamelName + ",";
            }
            returnstr = returnstr.Substring(0, returnstr.Length - 1);
            return returnstr;
        }

        /// <summary>
        /// 返回判断实体主键为空字符串
        /// </summary>
        /// <returns></returns>
        private string GetCheckIsNullPrimaryList()
        {
            if (Tbl.PrimaryKey == null) return "";
            string returnstr = null;
            foreach (IColumn col in Tbl.PrimaryKey.Columns)
            {
                if (col.DataType.CSharpType == "string")
                    returnstr += "String.IsNullOrEmpty(" + Tbl.CamelName + "." + col.PascalName + ") || ";
                else if (col.DataType.CSharpType.IndexOf('?') != -1)
                {
                    returnstr += "!" + Tbl.CamelName + "." + col.PascalName + ".HasValue || ";
                }
                else if (col.DataType.CSharpType == "Guid")
                {
                    returnstr += Tbl.CamelName + "." + col.PascalName + "==Guid.Empty|| ";
                }
                else
                {
                    returnstr += "String.IsNullOrEmpty(Convert.ToString(" + Tbl.CamelName + "." + col.PascalName + ")) || ";
                }
            }
            if (returnstr.Substring(returnstr.Length - 3, 3) == "|| ")
                returnstr = returnstr.Substring(0, returnstr.Length - 3);
            return returnstr;
        }

        /// <summary>
        /// 返回不带类型的主键集合串
        /// </summary>
        /// <returns></returns>
        private string GetPrimaryParaListNoCsType()
        {
            if (Tbl.PrimaryKey == null) return "";
            string returnstr = "";
            foreach (IColumn col in Tbl.PrimaryKey.Columns)
            {
                returnstr += col.CamelName + ",";
            }

            returnstr = returnstr.Substring(0, returnstr.Length - 1);
            return returnstr;
        }
        /// <summary>
        /// 返回主键类型
        /// </summary>
        /// <returns></returns>
        private string GetPrimaryDataType()
        {
            String PKType = "";
            foreach (IColumn item in Tbl.Columns)
            {
                if (item.IsPrimaryKey)
                {
                    PKType = item.DataType.CSharpType;
                }
            }
            return PKType;
        }


        private string GetewPascalName()
        {
            //去掉表名中的第一个 T
            string NewPascalName = "";
            if (Tbl.PascalName.IndexOf('T') == 0 || Tbl.PascalName.IndexOf('R') == 0 || Tbl.PascalName.IndexOf('G') == 0 || Tbl.PascalName.IndexOf('Z') == 0 || Tbl.PascalName.IndexOf('J') == 0 || Tbl.PascalName.IndexOf('D') == 0)
            {
                NewPascalName = Tbl.PascalName.Substring(1, Tbl.PascalName.Length - 1);
            }
            else { NewPascalName = Tbl.PascalName; }
            return NewPascalName;
        }



        public string Lower()
        {
            string str = GetewPascalName();
            string newStr = string.Empty;

            if (str.Length > 0)
            {
                newStr = str.Substring(0, 1).ToLower() + str.Substring(1);
            }
            return newStr;
        }

    }
}
