﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Esint.CodeBuilder.InterFace;
using System.Windows.Forms;
using Esint.TemplateCommon;

namespace Esint.Template.TemplateWeb
{
    /// <summary>
    /// 提供生成模板页面的功能.
    /// </summary>
    public class WebListJava2Template
    {
        #region 模板接口

        //生成代码的主表
        private IDbTable _tbl;

        //表空间
        private string _nameSpace;

        //文件名
        private string _fileName;

        //代码类型列表
        private List<ICodeType> _codeTypeList;

        // 操作者姓名
        private string _operName;

        //连接字符串
        private string _connectString;

        // 数据访问类
        private ICodeBuilder _dataAccess;

        // 表列表(用于多表生成)
        private List<IDbTable> _tbls;

        // 是否打包生成(即是否批量生成)
        private bool _isPackage;

        //程序名称(为名称空间指定名称时使用，因为bll和dal层是不能全称的。)
        private string _appName;

        /// <summary>
        /// 选择字段的GridView
        /// </summary>
        private DataGridView gv_Cols;

        /// <summary>
        /// 主表关联表的GridView
        /// </summary>
        private DataGridView gv_SubTable;
        #endregion

        public WebListJava2Template(IDbTable tbl, string nameSpace, string fileName, List<ICodeType> codeTypeList, string operName,
        string connectString, ICodeBuilder dataAccess, List<IDbTable> tbls, bool isPackage, string appName)
        {
            _tbl = tbl;
            _nameSpace = nameSpace;
            _fileName = fileName;
            _codeTypeList = codeTypeList;
            _operName = operName;
            _connectString = connectString;
            _dataAccess = dataAccess;
            _tbls = tbls;
            _isPackage = isPackage;
            _appName = appName;
        }

        #region 生成 mapper 代码

        /// <summary>
        /// 生成mybatis-3的Mapper Xml文件
        /// </summary>
        /// <param name="txtFileName">文件名</param>
        /// <param name="mainTableAlias">主表的别名</param>
        /// <param name="gv_Cols">选择字段的GridView</param>
        /// <param name="gv_SubTable">主表关联表的GridView</param>
        /// <param name="gv_ColsWhere">选择条件的GridView</param>
        /// <param name="isWhere">是否拼接Where</param>
        /// <returns></returns>
        public IReturnCode GetMapperXml(string txtFileName, string mainTableAlias, DataGridView gv_Cols, DataGridView gv_SubTable,
            DataGridView gv_ColsWhere, bool isWhere)
        {
            StringBuilder sb = new StringBuilder();

            sb.AppendLine();

            #region 生成代码区
            sb.AppendLine("<select id=\"select" + txtFileName + "\" resultType=\"java.util.Map\" parameterType=\"java.util.Map\">");
            sb.AppendLine("	<include refid=\"Base_Page_Begin\" />");
            sb.AppendLine(GetSqlString(mainTableAlias, gv_Cols, gv_SubTable));
            // 如果生成Where条件查询,则生成该部分代码
            if (isWhere)
            {
                sb.Append(GetXmlSqlWhereString(gv_ColsWhere));
            }
            sb.AppendLine("	<include refid=\"Base_Page_End\" />");
            sb.AppendLine("</select>");

            sb.AppendLine("<select id=\"select" + txtFileName + "Count\" resultType=\"java.lang.Integer\" parameterType=\"java.util.Map\">");
            sb.AppendLine(GetSqlString(mainTableAlias, gv_Cols, gv_SubTable, true));
            // 如果生成Where条件查询,则生成该部分代码
            if (isWhere)
            {
                sb.Append(GetXmlSqlWhereString(gv_ColsWhere));
            }
            sb.AppendLine("</select>");
            #endregion

            ReturnCode returnCode = new ReturnCode();
            returnCode.CodeText = sb;
            returnCode.FileName = txtFileName + "Mapper.xml";
            returnCode.CodeType = "JAVA";
            return returnCode;
        }

        /// <summary>
        /// 生成mybatis-3的Mapper Java文件
        /// </summary>
        /// <param name="txtFileName">文件名</param>
        /// <returns></returns>
        public IReturnCode GetMapperJava(string txtFileName)
        {
            StringBuilder sb = new StringBuilder();

            sb.AppendLine();
            #region 生成代码区

            sb.AppendLine("/**");
            sb.AppendLine("* 根据条件获取数据列表");
            sb.AppendLine("* ");
            sb.AppendLine("* @param params");
            sb.AppendLine("*            其中isPage 1分页 0不分页");
            sb.AppendLine("* @return");
            sb.AppendLine("* @throws Exception");
            sb.AppendLine("*/");
            sb.AppendLine("public List<Map<String, Object>> select" + txtFileName + "(Map<String, Object> params)");
            sb.AppendLine("		throws Exception;");
            sb.AppendLine();
            sb.AppendLine("/**");
            sb.AppendLine("* 根据条件获取数据总量");
            sb.AppendLine("* ");
            sb.AppendLine("* @return");
            sb.AppendLine("* @throws Exception");
            sb.AppendLine("*/");
            sb.AppendLine("public int select" + txtFileName + "Count(Map<String, Object> params)");
            sb.AppendLine("		throws Exception;");

            #endregion

            ReturnCode returnCode = new ReturnCode();
            returnCode.CodeText = sb;
            returnCode.FileName = txtFileName + "Mapper.java";
            returnCode.CodeType = "JAVA";
            return returnCode;
        }

        #endregion

        #region 生成 service

        /// <summary>
        /// 生成Service接口文件
        /// </summary>
        /// <param name="txtFileName">文件名</param>
        /// <returns></returns>
        public IReturnCode GetServiceJava(string txtFileName)
        {
            StringBuilder sb = new StringBuilder();

            sb.AppendLine();
            #region 生成代码区

            sb.AppendLine("/**");
            sb.AppendLine("* 根据条件获取数据列表");
            sb.AppendLine("* ");
            sb.AppendLine("* @param params");
            sb.AppendLine("*            其中isPage 1分页 0不分页");
            sb.AppendLine("* @return");
            sb.AppendLine("* @throws Exception");
            sb.AppendLine("*/");
            sb.AppendLine("public Map<String, Object> query" + txtFileName + "PageList(Map<String, Object> params)");
            sb.AppendLine("		throws Exception;");

            #endregion

            ReturnCode returnCode = new ReturnCode();
            returnCode.CodeText = sb;
            returnCode.FileName = txtFileName + "Service.java";
            returnCode.CodeType = "JAVA";
            return returnCode;
        }

        /// <summary>
        /// 生成Service实现文件
        /// </summary>
        /// <param name="txtFileName"></param>
        /// <returns></returns>
        public IReturnCode GetServiceImpJava(string txtFileName)
        {
            string pascalName = GetewPascalName();
            string lower = Lower();

            StringBuilder sb = new StringBuilder();

            sb.AppendLine();
            #region 生成代码区
            sb.AppendLine("/**");
            sb.AppendLine("* 根据条件获取数据列表-带分页列表");
            sb.AppendLine("* ");
            sb.AppendLine("* @return");
            sb.AppendLine("* @throws Exception");
            sb.AppendLine("*/");
            sb.AppendLine("public Map<String, Object> query" + txtFileName + "PageList(Map<String, Object> params) throws Exception {");
            sb.AppendLine("	Map<String, Object> result = new HashMap<String, Object>();");
            sb.AppendLine("	params.put(\"isPage\", 1);");
            sb.AppendLine("	int pages = Integer.parseInt(params.get(\"pages\").toString());");
            sb.AppendLine("	int rows = Integer.parseInt(params.get(\"rows\").toString());");
            sb.AppendLine("	int _begin = ((pages - 1) * rows) + 1;");
            sb.AppendLine("	int _end = pages * rows;");
            sb.AppendLine("	params.put(\"_begin\", _begin);");
            sb.AppendLine("	params.put(\"_end\", _end);");
            sb.AppendLine("	int rowcount = " + lower + "Mapper.select" + txtFileName + "Count(params);");
            sb.AppendLine("	if (rowcount > 0) {");
            sb.AppendLine("		result.put(\"total\", rowcount);");
            sb.AppendLine("		result.put(\"data\", " + lower + "Mapper.select" + txtFileName + "(params));");
            sb.AppendLine("	}");
            sb.AppendLine("	else {");
            sb.AppendLine("		result.put(\"total\", 0);");
            sb.AppendLine("		result.put(\"data\", new ArrayList<Map<String, Object>>());");
            sb.AppendLine("	}");
            sb.AppendLine("	return result;");
            sb.AppendLine("}");
            #endregion

            ReturnCode returnCode = new ReturnCode();
            returnCode.CodeText = sb;
            returnCode.FileName = txtFileName + "ServiceImpl.java";
            returnCode.CodeType = "JAVA";
            return returnCode;
        }

        #endregion

        #region 生成 controller

        /// <summary>
        /// 生成Controller
        /// </summary>
        /// <param name="txtFileName"></param>
        /// <returns></returns>
        public IReturnCode GetControllerJava(string txtFileName)
        {
            string pascalName = GetewPascalName();
            string lower = Lower();

            StringBuilder sb = new StringBuilder();

            sb.AppendLine();
            #region 生成代码区

            sb.AppendLine("/**");
            sb.AppendLine("* 根据条件获取数据列表-带分页");
            sb.AppendLine("* ");
            sb.AppendLine("* @return");
            sb.AppendLine("* @throws Exception");
            sb.AppendLine("*/");
            sb.AppendLine("@RequestMapping(value =\"/query" + txtFileName + "PageList.do\",method = RequestMethod.POST)");
            sb.AppendLine("@ResponseBody");
            sb.AppendLine("public Map<String, Object> query" + txtFileName + "PageList() throws Exception {");
            sb.AppendLine("	Map<String, Object> params = Common.getParams(request);");
            sb.AppendLine("	return " + lower + "Service.query" + txtFileName + "PageList(params);");
            sb.AppendLine("}");

            #endregion

            ReturnCode returnCode = new ReturnCode();
            returnCode.CodeText = sb;
            returnCode.FileName = txtFileName + "Controller.java";
            returnCode.CodeType = "JAVA";
            return returnCode;
        }

        #endregion

        #region 生成页面列表文件

        /// <summary>
        /// 生成JSP文件
        /// </summary>
        /// <param name="txtFileName">文件名</param>
        /// <param name="isWhere">是否生成查询条件</param>
        /// <param name="isQuery">操作列-是否生成查看按钮</param>
        /// <param name="isEdit">操作列-是否生成修改按钮</param>
        /// <param name="isDelete">操作列-是否生成删除按钮</param>
        /// <param name="isCheck">行头-是否生成复选框</param>
        /// <param name="isNum">行头-是否生成序号列</param>
        /// <param name="isPage">分页-是否分页</param>
        /// <param name="pageSize">分页-每页多少行</param>
        /// <returns></returns>
        public IReturnCode GetPageJsp(string txtFileName, bool isWhere, bool isQuery, bool isEdit, bool isDelete, bool isCheck, bool isNum, bool isPage,
            string pageSize, DataGridView gv_Cols, DataGridView gv_SubTable,
            DataGridView gv_ColsWhere)
        {
            string pascalName = GetewPascalName();
            string lower = Lower();

            StringBuilder sb = new StringBuilder();
            sb.AppendLine();

            #region 生成代码区
            //TODO ....
            sb.AppendLine("<%@ page language=\"java\" import=\"java.util.*\" pageEncoding=\"utf-8\"%>");
            sb.AppendLine("<!DOCTYPE HTML PUBLIC " + "-//W3C//DTD HTML 4.01 Transitional//EN" + ">");

            //2018-03-09 赵秀玲 新加 拼接路径开始==========================
            sb.AppendLine("<%String path = request.getContextPath();String basePath = request.getScheme()+" + "\"://" + "" + "\"");
            //sb.AppendLine("\"://"+""+"\"");
            sb.AppendLine("+request.getServerName()+" + "\":\"" + "+request.getServerPort()+path+" + "\"/\"" + ";%>");
            //sb.AppendLine("\"/\"" + ";%>");
            //2018-03-09 赵秀玲 新加 拼接路径完毕==========================



            sb.AppendLine("<html>");
            sb.AppendLine("<head>");
            sb.AppendLine("<title>列表</title>");
            //2018-03-09 赵秀玲 修改 动态生成basePath
            sb.AppendLine("<link rel=\"stylesheet\" type=\"text/css\" href=\"<%=basePath%>jsUtil/easyui/themes/default/easyui.css\">");



            sb.AppendLine("<link rel=\"stylesheet\" type=\"text/css\" href=\"<%=basePath%>jsUtil/easyui/themes/icon.css\">");
            sb.AppendLine("<link rel=\"stylesheet\" type=\"text/css\" href=\"<%=basePath%>jsUtil/easyui/demo.css\">");

            sb.AppendLine("<script type=\"text/javascript\">var basepath = \"<%=basePath%>\";</script>");

            sb.AppendLine("<script type=\"text/javascript\" src=\"<%=basePath%>jsUtil/jquery-1.9.1.min.js\"></script>");

            sb.AppendLine("<script type=\"text/javascript\" src=\"<%=basePath%>jsUtil/easyui/jquery.easyui.min.js\"></script>");

            sb.AppendLine("<script type=\"text/javascript\" src=\"<%=basePath%>jsUtil/easyui/locale/easyui-lang-zh_CN.js\"></script>");


            sb.AppendLine("<script type=\"text/javascript\"  src=\"<%=basePath%>jsUtil/zxTable.js\"></script>");

            //sb.AppendLine("<script type=\"text/javascript\"  src=\"<%=basePath%>jsUtil/easyui/jquery.easyui.min.js\"></script>");

            sb.AppendLine("<script type=\"text/jscript\" src=\"<%=basePath%>jsp/js/" + txtFileName + "" + Lower() + "List.js\"></script>");

            //sb.AppendLine("<script type=\"text/javascript\" src=\"" + txtFileName + "/scripts/" + Lower() + "List.js\"></script>");

            sb.AppendLine("</head>");

            sb.AppendLine("<body>");
            sb.AppendLine("<div>");
            //sb.AppendLine("<!-- 表格Div -->");

            //sb.AppendLine("<div id=\"grid\" ></div>");
            //sb.AppendLine("</body>");
            //sb.AppendLine("</html>");//拼接到尾部

           // sb.AppendLine("==========================================================");

            //查询条件
            if (isWhere)
            {
                foreach (DataGridViewRow row in gv_ColsWhere.Rows)
                {
                    if (row.Cells[1].Value.ToString() == "True")
                    {
                        if (row.Cells[8].Value.ToString() == "W文本框")
                        {
                            sb.AppendLine(row.Cells[2].Value.ToString() + "<input type=\"text\"" + "id=\"" + row.Cells[3].Value.ToString() + "_FieldID\"" + "/>");
                        }
                            //sb.AppendLine("id=\"" + row.Cells[3].Value.ToString() + "_FieldID\"");
                            //sb.AppendLine("/>");

                        if (row.Cells[8].Value.ToString() == "X下拉框")
                        {

                            sb.AppendLine(row.Cells[2].Value.ToString() + "<select" + " id=\"" + row.Cells[3].Value.ToString() + "_FieldID\"" + "</select>");
                            //sb.AppendLine("id=\"" + row.Cells[3].Value.ToString() + "_FieldID\"");                           
                            //sb.AppendLine("</select>");
                        }
                        if (row.Cells[8].Value.ToString() == "R日期框")
                        {
                           // sb.AppendLine("日期框:" + row.Cells[3].Value.ToString() + " " + row.Cells[8].Value.ToString());
                            sb.AppendLine(row.Cells[2].Value.ToString() + "<input type=\"text\"" + "id=\"" + row.Cells[3].Value.ToString() + "_FieldID\"" + " name=\"date\">");
                           
                        }
                    }
                }
            }
            sb.AppendLine("</div>");
            sb.AppendLine("<div>");
            //拼接查询和新增按钮
            sb.AppendLine("<input type=\"button\" onclick=\"search()\" value=\"查询\" />");
            sb.AppendLine("<input type=\"button\" onclick=\"add()\" value=\"新增\" />");
            sb.AppendLine("</div>");

            //拼接表格
            sb.AppendLine("<div id=\"tableDiv\"></div>");
            sb.AppendLine("</body>");
            sb.AppendLine("</html>");//拼接到尾部

            //sb.AppendLine("==========================================================");
            //行头复选
            //if (isCheck)
            //{
            //    sb.AppendLine("复选框");
            //}
            ////行头序号列
            //if (isNum)
            //{
            //    sb.AppendLine("序号列");
            //}
            ////数据源
            //foreach (DataGridViewRow row in gv_Cols.Rows)
            //{
            //    sb.AppendLine("字段: "+row.Cells["col_Field"].Value.ToString() + " " + row.Cells["col_Meaning"].Value.ToString() + " " + row.Cells["col_Alias"].Value.ToString());
            //}
            ////操作列
            //if (isQuery || isEdit || isDelete)
            //{
            //    if (isQuery)
            //    {
            //        sb.AppendLine("查看 " + _tbl.PrimaryKey.Columns[0].ColumnName);
            //    }
            //    if (isEdit)
            //    {
            //        sb.AppendLine("修改 " + _tbl.PrimaryKey.Columns[0].ColumnName);
            //    }
            //    if (isDelete)
            //    {
            //        sb.AppendLine("删除 " + _tbl.PrimaryKey.Columns[0].ColumnName);
            //    }
            //}
            //sb.AppendLine("==========================================================");
            ////分页处理
            //if (isPage)
            //{
            //    sb.AppendLine("分页: " + pageSize);
            //}
            #endregion

            ReturnCode returnCode = new ReturnCode();
            returnCode.CodeText = sb;
            returnCode.FileName = txtFileName + "List.jsp";
            returnCode.CodeType = "HTML";
            return returnCode;
        }

        /// <summary>
        /// 生成js文件
        /// </summary>
        /// <param name="txtFileName">文件名</param>
        /// <param name="isWhere">是否生成查询条件</param>
        /// <param name="isQuery">操作列-是否生成查看按钮</param>
        /// <param name="isEdit">操作列-是否生成修改按钮</param>
        /// <param name="isDelete">操作列-是否生成删除按钮</param>
        /// <param name="isCheck">行头-是否生成复选框</param>
        /// <param name="isNum">行头-是否生成序号列</param>
        /// <param name="isPage">分页-是否分页</param>
        /// <param name="pageSize">分页-每页多少行</param>
        /// <returns></returns>
        public IReturnCode GetPageJavaScript(string txtFileName, bool isWhere, bool isQuery, bool isEdit, bool isDelete, bool isCheck, bool isNum, bool isPage,
            string pageSize, DataGridView gv_Cols, DataGridView gv_SubTable,
            DataGridView gv_ColsWhere)
        {
            string pascalName = GetewPascalName();
            string lower = Lower();

            StringBuilder sb = new StringBuilder();
            sb.AppendLine();

            #region 生成代码区
            //TODO ....
            int selectCount = 0;
            foreach (DataGridViewRow row in gv_Cols.Rows)
            {
                if (row.Cells[0].Value.ToString() == "True")
                {
                    selectCount++;
                }
            }
            string primary = "";
            foreach (IColumn col in _tbl.PrimaryKey.Columns)
            {
                primary = col.CamelName;
            }
            //2018-03-12 赵秀玲修改
            //sb.AppendLine("    var formdata={};//form提交数据");
            sb.AppendLine("	$(function(){");
            sb.AppendLine("		initPage();");
            sb.AppendLine("	    });");

            //拼接initPage方法
            sb.AppendLine("function initPage() {");

            //查询条件
            if (isWhere)
            {
                foreach (DataGridViewRow row in gv_ColsWhere.Rows)
                {
                    if (row.Cells[1].Value.ToString() == "True")
                    {
                        
                        if (row.Cells[8].Value.ToString() == "X下拉框")
                        {
                            //sb.AppendLine(row.Cells[3].Value.ToString() + " " + row.Cells[8].Value.ToString());
                            //sb.AppendLine("$(" +"#" + row.Cells[3].Value.ToString() + "FieldID" + "" + ").combobox({");
                            sb.AppendLine("$(" + "\"" + "#" + row.Cells[3].Value.ToString() + "_FieldID" + "\"" + ").combobox({");
                            sb.AppendLine(" url : '',");
                            sb.AppendLine("	required : true,");
                            sb.AppendLine("	multiple : false,");
                            sb.AppendLine(" valueField : '',");
                            sb.AppendLine(" textField : '',");
                            sb.AppendLine(" panelHeight : 'auto',");
                            sb.AppendLine("	editable : false,");
                            sb.AppendLine(" panelHeight : 150");
                            sb.AppendLine("});");
                        }
                        if (row.Cells[8].Value.ToString() == "R日期框")
                        {
                            // sb.AppendLine("日期框:" + row.Cells[3].Value.ToString() + " " + row.Cells[8].Value.ToString());
                            sb.AppendLine("$(" + "\"" + "#" + row.Cells[3].Value.ToString() + "_FieldID" + "\"" + ").datebox({");
                            sb.AppendLine(" required : false,");
                            sb.AppendLine("	editable : false");
                            sb.AppendLine("});");
                        }
                    }
                }
            }
            sb.AppendLine("	tableDivWithPage();");
            sb.AppendLine("}");
            
            //拼接tableDivWithPage方法====================开始
            sb.AppendLine("function tableDivWithPage(){");
            sb.AppendLine("       var params = {");
            sb.AppendLine("           id : 'tableDiv',");
            sb.AppendLine("           url :basepath+\"" + Lower() + "/query" + GetewPascalName() + "PageList.do\",");
            sb.AppendLine("           title : [");
            foreach (DataGridViewRow row in gv_Cols.Rows)
            {
                //选中列
                if (row.Cells[0].Value.ToString() == "True")
                {

                    //sb.AppendLine("	       {title : \"" + row.Cells["col_Meaning"].Value.ToString() + "\",name : \"" + row.Cells["col_Field"].Value.ToString() + "\",width : 100, sortable:\"true\", sortName:\"" + row.Cells["col_Field"].Value.ToString() + "\",");
                    //sb.AppendLine("			maxLength : 10,showTip : true");
                    //if (selectCount > 0)
                    //{
                    //    if (row.Index == selectCount - 1)
                    //    { sb.AppendLine("	       }"); }
                    //    else
                    //    {
                    //        sb.AppendLine("	       },");
                    //    }
                    //}
                    sb.AppendLine("	            {  name : '\"" + row.Cells[2].Value.ToString() + "\"',");
                    sb.AppendLine("                width : 15,");
                    sb.AppendLine("                key:\'" + row.Cells[3].Value.ToString() + "\'");
                    sb.AppendLine("	            },");
                    //if (selectCount > 0)
                    //{
                    //    if (row.Index == selectCount - 1)
                    //    { sb.AppendLine("	       }"); }
                    //    else
                    //    {
                    //        sb.AppendLine("	       },");
                    //    }
                    //}
                }
            }
            //拼接操作列
            sb.AppendLine("              { name : '操作',");
            sb.AppendLine("                width : 35,");
            sb.AppendLine("                key : 'iseqUid',");
            sb.AppendLine("                formatter :function(index) { ");
            sb.AppendLine("                      var data = table1.data[index];");
            sb.AppendLine("// 取到当前行的数据 ");
            if (isQuery)
            {
                sb.AppendLine("                 var str =\"<a href=\'javascript:void(0);'" + "title='详情' onclick='viewById(id)'>详情</a>" + "\"");
            }
            if (isEdit)
            {
                sb.AppendLine("                 +\"<a href=\'javascript:void(0);'" + "title='修改' onclick='editById(id)'>修改</a>" + "\"");
            }
            if (isDelete)
            {
                sb.AppendLine("                +\"<a href=\'javascript:void(0);'" + "title='删除' onclick='confirmDelete(id)'>删除</a>" + "\"");
            }
            //sb.AppendLine("title='详情' onclick='viewById(\"data." + primary + "\")'>详情</a>" + "\"");
           
           
            sb.AppendLine("                    return str;");
            sb.AppendLine("                },");
            sb.AppendLine("  crud : true");
            sb.AppendLine("}],");
            //sb.AppendLine("          ],");
            sb.AppendLine("searchTerms : {");
            //查询条件
            if (isWhere)
            {
                foreach (DataGridViewRow row in gv_ColsWhere.Rows)
                {
                    if (row.Cells[1].Value.ToString() == "True")
                    {
                        if (row.Cells[8].Value.ToString() == "W文本框")
                            sb.AppendLine(             row.Cells[3].Value.ToString() + ":" + "$(" +"\"" +"#" + row.Cells[3].Value.ToString() + "_FieldID" + "\"" + ").val(),");
                        if (row.Cells[8].Value.ToString() == "X下拉框")
                        {
                            //sb.AppendLine("下拉框:" + row.Cells[3].Value.ToString() + " " + row.Cells[8].Value.ToString());
                            sb.AppendLine(row.Cells[3].Value.ToString() + ":" + "$(" + "\"" + "#" + row.Cells[3].Value.ToString() + "_FieldID" + "\"" + ").combobox(" + "\"" + "getValue" + "\"" + "),");
                        }
                        if (row.Cells[8].Value.ToString() == "R日期框")
                        {
                           // sb.AppendLine("日期框:" + row.Cells[3].Value.ToString() + " " + row.Cells[8].Value.ToString());
                            sb.AppendLine(row.Cells[3].Value.ToString() + ":" + "$(" + "\"" + "#" + row.Cells[3].Value.ToString() + "_FieldID" + "\"" + ").datebox(" + "\"" + "getValue" + "\"" + "),");
                        }
                    }
                }
            }
            sb.AppendLine("            },");
            
            //分页处理
            if (isPage)
            {
                sb.AppendLine("  dataLimit : " + pageSize + ",");
                //sb.AppendLine(pageSize+",");
            }
            sb.AppendLine("   dataLimits : [ 5, 10, 20 ],");
            //行头复选
            if (isCheck)
            {
                sb.AppendLine("selection : { ");
                sb.AppendLine("            type : 'checkbox',");
                sb.AppendLine("            pid : [ '" + primary + "' ],");
                sb.AppendLine("            colomn_shown : true,");
                sb.AppendLine("            width : 5");
                sb.AppendLine("            },");
            }
            //行头序号列
            if (isNum)
            {
                sb.AppendLine("auto_index:{");
                sb.AppendLine("            show: true,");
                sb.AppendLine("            title: '序号',");
                sb.AppendLine("            width: 5 ");
                sb.AppendLine("            }");
            }
            sb.AppendLine("   };");
            sb.AppendLine("table1 = new Table(params);");
            sb.AppendLine("}");
            //拼接tableDivWithPage方法====================结束

            //拼接查询方法===========search方法
            sb.AppendLine("function search() { ");
            sb.AppendLine("         var extra = {");


            //拼接查询条件
            if (isWhere)
            {
                foreach (DataGridViewRow row in gv_ColsWhere.Rows)
                {
                    if (row.Cells[1].Value.ToString() == "True")
                    {
                        if (row.Cells[8].Value.ToString() == "W文本框")
                        {
                            sb.AppendLine("$(" + "\"" + "#" + row.Cells[3].Value.ToString() + "_FieldID" + "\"" + ").val(),");
                        }
                        if (row.Cells[8].Value.ToString() == "X下拉框")
                        {
                            //sb.AppendLine("下拉框:" + row.Cells[3].Value.ToString() + " " + row.Cells[8].Value.ToString());
                            sb.AppendLine("$(" + "\"" + "#" + row.Cells[3].Value.ToString() + "_FieldID" + "\"" + ").combobox(" + "\""+"getValue" + "\""+"),");
                        }
                        if (row.Cells[8].Value.ToString() == "R日期框")
                        {
                            // sb.AppendLine("日期框:" + row.Cells[3].Value.ToString() + " " + row.Cells[8].Value.ToString());
                            sb.AppendLine("$(" + "\"" + "#" + row.Cells[3].Value.ToString() + "_FieldID" + "\"" + ").datebox(" + "\"" + "getValue" + "\"" + ")");
                        }
                    }
                }
            }

            sb.AppendLine("};");
            sb.AppendLine(" table1.refresh(extra);");
            sb.AppendLine("}");

            //拼接新增方法
            sb.AppendLine("function add() {");
            sb.AppendLine("         window.location.href = "+""+";");
            sb.AppendLine(" }");
            //拼接查看方法
            sb.AppendLine("function viewById(id) {");
            sb.AppendLine("         window.location.href = "+""+";");
            sb.AppendLine("}");


            //拼接修改方法
            sb.AppendLine("function editById(id) {");
            sb.AppendLine("          window.location.href = " + "" + ";");
            sb.AppendLine("}");

            //拼接删除方法==============弹出提示
            sb.AppendLine("function confirmDelete(id) {");
            sb.AppendLine("         $.messager.confirm('提示', '请判断是否要删除?', function(b) {");
            sb.AppendLine("            if (b) { ");
            sb.AppendLine("                deleteById(id);");
            sb.AppendLine("                }");
            sb.AppendLine("            });");
            sb.AppendLine("}");

            //拼接异步删除
            sb.AppendLine("function deleteById(id) {");
            sb.AppendLine("var param = {};");
            sb.AppendLine("param.id = id;");
            sb.AppendLine("$.ajax({");
            sb.AppendLine("    async : false,");
            sb.AppendLine("    url : basepath + \"" + Lower() + "/del" + GetewPascalName() + ".do\",");
            sb.AppendLine("    type : \"POST\",");
            sb.AppendLine("    data : param,");
            sb.AppendLine("    dataType : \"json\",");
            sb.AppendLine("    success : function(res) {");
            sb.AppendLine("         $(function() {");
            sb.AppendLine("              $.messager.alert(\"操作提示\", \"删除成功！\", \"info\");");
            sb.AppendLine("           });");
            sb.AppendLine("     },");
            sb.AppendLine("    error : function(request) {");
            sb.AppendLine("       $(function() {");
            sb.AppendLine("           $.messager.alert(\"操作提示\", \"删除失败！\", \"info\");");
            sb.AppendLine("        });");
            sb.AppendLine("       }");
            sb.AppendLine("   });");
            sb.AppendLine("  }");
          

            //sb.AppendLine("		//表格按钮");
            //sb.AppendLine("		var buttons = [");
            //sb.AppendLine("		       		{content: '<button class=\"btn btn-primary\" type=\"button\"><span class=\"glyphicon glyphicon-plus\"><span>创建</button>', action: 'add'},");
            //sb.AppendLine("		            {content: '<button class=\"btn btn-success\" type=\"button\"><span class=\"glyphicon glyphicon-edit\"></span>&nbsp;修改</button>', action: 'edit'},");
            //sb.AppendLine("		            {content: '<button class=\"btn btn-danger\" type=\"button\"><span class=\"glyphicon glyphicon-remove\"></span>&nbsp;删除</button>', action: 'del'}");
            //sb.AppendLine("	            ];");

            //sb.AppendLine("		 /**");
            //sb.AppendLine("		  * 初始化表格");
            //sb.AppendLine("		  */");
            //sb.AppendLine("		$(\"#grid\").grid({");
            //sb.AppendLine("			 identity: '" + primary + "',");
            //sb.AppendLine("             columns: columns,");
            //sb.AppendLine("             buttons: buttons,");

            //sb.AppendLine("             isUserLocalData:false,			//如果为false，则发送ajax请求到url端，获取数据，否则，则视为获取静态数据");
            //sb.AppendLine("             url:basepath+\"" + Lower() + "/query" + GetewPascalName() + "List.do\",");
            //sb.AppendLine("             isShowIndexCol:true,//是否显示复选框");
            //sb.AppendLine("             pageNo:1,//分页起始页");
            //sb.AppendLine("             pageSize:50,//分页");
            //sb.AppendLine("             showPage:5//分页快捷显示页数");
            //sb.AppendLine("        }).on({");
            //sb.AppendLine("        	//创建按钮事件");
            //sb.AppendLine("        	'add': function(){");
            //sb.AppendLine("        		add();      		");
            //sb.AppendLine("        	},");
            //sb.AppendLine("        	'edit': function(event, data){");
            //sb.AppendLine("        		edit(event, data);");
            //sb.AppendLine("        	},");
            //sb.AppendLine("        	'del': function(event, data){ ");
            //sb.AppendLine("        		showRemoveTip(event,data);");
            //sb.AppendLine("        	}");
            //sb.AppendLine("	    })");
            //sb.AppendLine("});");


           
            //行头复选
            //if (isCheck)
            //{
            //    sb.AppendLine("复选框");
            //}
            ////行头序号列
            //if (isNum)
            //{
            //    sb.AppendLine("序号列");
            //}
            ////数据源
            //foreach (DataGridViewRow row in gv_Cols.Rows)
            //{
            //    sb.AppendLine("数据源 " + row.Cells["col_Field"].Value.ToString() + " " + row.Cells["col_Meaning"].Value.ToString() + " " + row.Cells["col_Alias"].Value.ToString());
            //}
            //操作列
            //if (isQuery || isEdit || isDelete)
            //{
            //    if (isQuery)
            //    {
            //        sb.AppendLine("查看 " + _tbl.PrimaryKey.Columns[0].ColumnName);
            //    }
            //    if (isEdit)
            //    {
            //        sb.AppendLine("修改 " + _tbl.PrimaryKey.Columns[0].ColumnName);
            //    }
            //    if (isDelete)
            //    {
            //        sb.AppendLine("删除 " + _tbl.PrimaryKey.Columns[0].ColumnName);
            //    }
            //}
            ////分页处理
            //if (isPage)
            //{
            //    sb.AppendLine("分页: " + pageSize);
            //}
            #endregion

            ReturnCode returnCode = new ReturnCode();
            returnCode.CodeText = sb;
            returnCode.FileName = txtFileName + "List.js";
            returnCode.CodeType = "JS";
            return returnCode;
        }

        #endregion

        #region 其他
        /// <summary>
        /// 获得拼接的SQL语句
        /// </summary>
        /// <param name="mainTableAlias">主表的别名</param>
        /// <param name="gv_Cols">选择字段的GridView</param>
        /// <param name="gv_SubTable">主表关联表的GridView</param>
        /// <param name="isCount">select后面是否为Count(*)</param>
        /// <returns></returns>
        public string GetSqlString(string mainTableAlias, DataGridView gv_Cols, DataGridView gv_SubTable, bool isCount = false)
        {
            string sql = "		SELECT ";

            if (isCount)
            {
                sql += " count(*) ";
            }
            else
            {
                //拼接主键.
                foreach (IColumn col in _tbl.PrimaryKey.Columns)
                {
                    sql += mainTableAlias + "." + col.ColumnName + ",";
                }
                //拼接选择的列
                foreach (DataGridViewRow row in gv_Cols.Rows)
                {
                    if (row.Cells["col_Select"].Value.ToString() == "True")
                    {
                        if (row.Cells["col_IsCode"].Value != null && row.Cells["col_IsCode"].Value.ToString() == "True")
                        {
                            sql += "(" + string.Format(_dataAccess.CodeSQL, row.Cells["col_Code"].Value.ToString(), row.Cells["col_TableAlias"].Value.ToString() + "." + row.Cells["col_Field"].Value.ToString()) + ")  As " + row.Cells["col_Alias"].Value.ToString() + ",";
                        }
                        else
                        {
                            sql += row.Cells["col_TableAlias"].Value.ToString() + "." + row.Cells["col_Field"].Value.ToString() + " As " + row.Cells["col_Alias"].Value.ToString() + ",";
                        }
                    }
                }

                sql = sql.Substring(0, sql.Length - 1);
            }

            sql += "\r\n		FROM " + _tbl.TableName + " " + mainTableAlias + " ";

            foreach (DataGridViewRow row in gv_SubTable.Rows)
            {
                if (row.Cells[0].Value.ToString() == "True")
                {
                    if (row.Cells[5].Value != null && row.Cells[5].Value.ToString() != "")
                    {
                        sql += "\r\n			" + row.Cells[1].Value.ToString().ToString() + " " + row.Cells[5].Value.ToString() + " " + row.Cells[3].Value.ToString() + " " + row.Cells[4].Value.ToString();
                    }
                    else
                    {
                        sql += "\r\n			" + row.Cells[1].Value.ToString().ToString() + " " + row.Cells[2].Value.ToString() + " " + row.Cells[3].Value.ToString() + " " + row.Cells[4].Value.ToString();
                    }
                }
            }

            return sql;
        }

        /// <summary>
        /// 获得Xml文件SQLWhere 条件字符串
        /// </summary>
        /// <param name="gv_ColsWhere">选择条件的GridView</param>
        /// <returns></returns>
        public string GetXmlSqlWhereString(DataGridView gv_ColsWhere)
        {
            if (gv_ColsWhere == null || gv_ColsWhere.Rows.Count == 0) return "";

            StringBuilder sb = new StringBuilder();
            int i = 0;
            sb.AppendLine("		<where>");
            foreach (DataGridViewRow row in gv_ColsWhere.Rows)
            {
                // 如果不显示,但选中了,判断是否己赋值,如己赋值,在SQL语句中拼上,没赋值,拼上属性
                if (row.Cells[0].Value.ToString() == "True")
                {
                    IColumn col = GetColByName(row.Cells[5].Value.ToString(), row.Cells[3].Value.ToString());

                    if (_dataAccess.DataBaseType == "ORACLE")
                    {
                        if (col.DataType.DbDataType.ToUpper() == "DATE")
                        {
                            sb.AppendLine("			<if test=\"" + OneStringLower(col.PascalName) + " != null and " + OneStringLower(col.PascalName) + " != ''\">");
                            sb.AppendLine("				 AND " + col.ColumnName.ToUpper() + " = TO_DATE(#{" + OneStringLower(col.PascalName) + "},'YYYY-MM-DD HH24:MI:SS')");
                            sb.AppendLine("			</if>");
                        }
                        else if (col.DataType.DbDataType.ToUpper() == "NUMBER" || col.DataType.DbDataType.ToUpper() == "INTEGER")
                        {
                            sb.AppendLine("		    <if test=\"(" + OneStringLower(col.PascalName) + " != null and " + OneStringLower(col.PascalName) + " != '') or " + OneStringLower(col.PascalName) + " == 0\">");
                            sb.AppendLine("			 	 AND " + col.ColumnName.ToUpper() + " = #{" + OneStringLower(col.PascalName) + "}");
                            sb.AppendLine("		    </if>");
                        }
                        else
                        {
                            sb.AppendLine("			<if test=\"" + OneStringLower(col.PascalName) + " != null and " + OneStringLower(col.PascalName) + " != ''\">");
                            sb.AppendLine("				 AND " + col.ColumnName.ToUpper() + " = #{" + OneStringLower(col.PascalName) + "}");
                            sb.AppendLine("			</if>");
                        }
                    }
                    if (_dataAccess.DataBaseType == "SQLSERVER")
                    {
                        if (col.DataType.DbDataType.ToUpper() == "DECIMAL" || col.DataType.DbDataType.ToUpper() == "INT" || col.DataType.DbDataType.ToUpper() == "FLOAT" || col.DataType.DbDataType.ToUpper() == "MONEY" || col.DataType.DbDataType.ToUpper() == "NUMERIC")
                        {
                            sb.AppendLine("		    <if test=\"(" + OneStringLower(col.PascalName) + " != null and " + OneStringLower(col.PascalName) + " != '') or " + OneStringLower(col.PascalName) + " == 0\">");
                            sb.AppendLine("			 	 AND " + col.ColumnName.ToUpper() + " = #{" + OneStringLower(col.PascalName) + "}");
                            sb.AppendLine("		    </if>");
                        }
                        else
                        {
                            sb.AppendLine("			<if test=\"" + OneStringLower(col.PascalName) + " != null and " + OneStringLower(col.PascalName) + " != ''\">");
                            sb.AppendLine("				 AND " + col.ColumnName.ToUpper() + " = #{" + OneStringLower(col.PascalName) + "}");
                            sb.AppendLine("			</if>");
                        }
                    }
                    if (_dataAccess.DataBaseType == "MYSQL")
                    {
                        if (col.DataType.DbDataType.ToUpper() == "DECIMAL" || col.DataType.DbDataType.ToUpper() == "INTEGER" || col.DataType.DbDataType.ToUpper() == "INT" || col.DataType.DbDataType.ToUpper() == "FLOAT" || col.DataType.DbDataType.ToUpper() == "DOUBLE")
                        {
                            sb.AppendLine("		    <if test=\"(" + OneStringLower(col.PascalName) + " != null and " + OneStringLower(col.PascalName) + " != '') or " + OneStringLower(col.PascalName) + " == 0\">");
                            sb.AppendLine("			 	 AND " + col.ColumnName.ToUpper() + " = #{" + OneStringLower(col.PascalName) + "}");
                            sb.AppendLine("		    </if>");
                        }
                        else
                        {
                            sb.AppendLine("			<if test=\"" + OneStringLower(col.PascalName) + " != null and " + OneStringLower(col.PascalName) + " != ''\">");
                            sb.AppendLine("				 AND " + col.ColumnName.ToUpper() + " = #{" + OneStringLower(col.PascalName) + "}");
                            sb.AppendLine("			</if>");
                        }
                    }
                }
            }
            sb.AppendLine("		</where>");

            return sb.ToString();
        }

        #endregion


        #region private

        /// <summary>
        /// 将字段的首字母变成小写，其他驼峰命名规则
        /// </summary>
        /// <param name="colname"></param>
        /// <returns></returns>
        private string OneStringLower(string colname)
        {
            string newcolname = "";
            newcolname = colname.Substring(0, 1).ToLower();
            newcolname += colname.Substring(1, colname.Length - 1);
            return newcolname;
        }

        /// <summary>
        /// 去掉表格中的T然后首字母大写.
        /// </summary>
        /// <returns></returns>
        private string GetewPascalName()
        {
            //去掉表名中的第一个 T
            string NewPascalName = "";
            if (_tbl.PascalName.IndexOf('T') == 0)
            {
                NewPascalName = _tbl.PascalName.Substring(1, _tbl.PascalName.Length - 1);
            }
            else { NewPascalName = _tbl.PascalName; }
            return NewPascalName;
        }

        private string Lower()
        {
            string str = GetewPascalName();
            string newStr = string.Empty;

            if (str.Length > 0)
            {
                newStr = str.Substring(0, 1).ToLower() + str.Substring(1);
            }
            return newStr;
        }

        /// <summary>
        /// 根据表名和列表得到IColumn对象.
        /// </summary>
        /// <param name="tableName"></param>
        /// <param name="colName"></param>
        /// <returns></returns>
        private IColumn GetColByName(string tableName, string colName)
        {
            IDbTable table;
            if (tableName.ToUpper() != _tbl.TableName.ToUpper())
                table = _dataAccess.GetTableByTableName(_connectString, tableName);
            else
                table = _tbl;
            IColumn col1 = table.Columns.Find(delegate(IColumn col) { return col.ColumnName == colName; });
            return col1;
        }

        #endregion
    }
}
