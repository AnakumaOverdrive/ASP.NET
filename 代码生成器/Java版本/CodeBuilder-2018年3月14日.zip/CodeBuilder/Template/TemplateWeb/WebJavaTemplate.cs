﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Esint.CodeBuilder.InterFace;
using System.Windows.Forms;
using Esint.TemplateCommon;

namespace Esint.Template.TemplateWeb
{
    /// <summary>
    /// 提供生成模板页面的功能.
    /// </summary>
    public class WebJavaTemplate
    {
        #region 模板接口

        //生成代码的主表
        private IDbTable _tbl;

        //表空间
        private string _nameSpace;

        //文件名
        private string _fileName;

        //代码类型列表
        private List<ICodeType> _codeTypeList;

        // 操作者姓名
        private string _operName;

        //连接字符串
        private string _connectString;

        // 数据访问类
        private ICodeBuilder _dataAccess;

        // 表列表(用于多表生成)
        private List<IDbTable> _tbls;

        // 是否打包生成(即是否批量生成)
        private bool _isPackage;

        //程序名称(为名称空间指定名称时使用，因为bll和dal层是不能全称的。)
        private string _appName;

        /// <summary>
        /// 选择字段的GridView
        /// </summary>
        private DataGridView gv_Cols;

        /// <summary>
        /// 主表关联表的GridView
        /// </summary>
        private DataGridView gv_SubTable;
        #endregion

        #region  样式设置 --> 改为配置文件形式

        string textBoxCss = "TextBox"; //W文本框样式

        string mustTextBoxCss = "MustTextBox"; //必填项W文本框样式

        string tb_Form = "tb_form"; //表单样式

        string td_label = "td_Label"; //B标签单元格样式

        string td_input = "td_Input"; //输入域单元格样式

        string td_inputW = "td_InputW"; //输入域单元格样式

        string td_MaxInput = "td_MaxInput"; // 跨列输入域样式

        string dropDownListCss = "DropDownList"; //下拉列表样式

        string MustdropDownList = "MustDropDownList"; //必填下拉列表样式

        string checkBoxCss = "CheckBoxCss"; //F复选框样式

        string mustCheckBoxCss = "MustCheckBoxCss"; // 必填F复选框样式

        string requestCss = "requestCss"; //必填提示符样式

        #endregion

        public WebJavaTemplate(IDbTable tbl, string nameSpace, string fileName, List<ICodeType> codeTypeList, string operName,
        string connectString, ICodeBuilder dataAccess, List<IDbTable> tbls, bool isPackage, string appName)
        {
            _tbl = tbl;
            _nameSpace = nameSpace;
            _fileName = fileName;
            _codeTypeList = codeTypeList;
            _operName = operName;
            _connectString = connectString;
            _dataAccess = dataAccess;
            _tbls = tbls;
            _isPackage = isPackage;
            _appName = appName;
        }

        #region 查看页面

        public IReturnCode GetViewPageJsp(string txtFileName, DataGridView gv_Setting)
        {
            StringBuilder sb = new StringBuilder();

            #region 生成代码区
            foreach (DataGridViewRow row in gv_Setting.Rows)
            {
                
                try
                {
                    //判断是否选中.
                    if (Convert.ToBoolean(row.Cells[1].EditedFormattedValue))
                    {
                        IColumn col = _tbl.Columns.Find(delegate(IColumn tcol) { return tcol.ColumnName == row.Cells[0].Value.ToString(); });
                    }
                    sb.AppendLine(string.Format("列名:{0};选择:{1};含义:{2};控件:{3};代码:{4};必填:{5};跨列:{6};"
                        , row.Cells[0].Value
                        , row.Cells[1].Value
                        , row.Cells[2].Value
                        , row.Cells[3].Value
                        , row.Cells[4].Value
                        , row.Cells[5].Value
                        , row.Cells[6].Value));
                }
                catch (Exception ex)
                {
                    Console.Write(ex.Message);
                }
            }

            //主键
            foreach (IColumn col in _tbl.PrimaryKey.Columns)
            {
                sb.AppendLine(col.DataType.CSharpType + " " + col.PascalName + " " + col.ControlProperty.Tag + " " + col.Description);
            }

            #endregion

            ReturnCode returnCode = new ReturnCode();
            returnCode.CodeText = sb;
            returnCode.FileName = txtFileName + "View.jsp";
            returnCode.CodeType = "HTML";
            return returnCode;
        }

        public IReturnCode GetViewPageJs(string txtFileName, DataGridView gv_Setting)
        {
            StringBuilder sb = new StringBuilder();

            ReturnCode returnCode = new ReturnCode();
            returnCode.CodeText = sb;
            returnCode.FileName = txtFileName + "View.js";
            returnCode.CodeType = "HTML";
            return returnCode;
        }

        #endregion

        #region 修改页面
        public IReturnCode GetEditPageJsp(string txtFileName, DataGridView gv_Setting)
        {
            StringBuilder sb = new StringBuilder();

            ReturnCode returnCode = new ReturnCode();
            returnCode.CodeText = sb;
            returnCode.FileName = txtFileName + "Edit.jsp";
            returnCode.CodeType = "HTML";
            return returnCode;
        }

        public IReturnCode GetEditPageJs(string txtFileName, DataGridView gv_Setting)
        {
            StringBuilder sb = new StringBuilder();

            ReturnCode returnCode = new ReturnCode();
            returnCode.CodeText = sb;
            returnCode.FileName = txtFileName + "Edit.js";
            returnCode.CodeType = "HTML";
            return returnCode;
        }
        #endregion

        #region 添加页面
        public IReturnCode GetAddPageJsp(string txtFileName, DataGridView gv_Setting)
        {
            StringBuilder sb = new StringBuilder();

            ReturnCode returnCode = new ReturnCode();
            returnCode.CodeText = sb;
            returnCode.FileName = txtFileName + "Add.jsp";
            returnCode.CodeType = "HTML";
            return returnCode;
        }

        public IReturnCode GetAddPageJs(string txtFileName, DataGridView gv_Setting)
        {
            StringBuilder sb = new StringBuilder();

            ReturnCode returnCode = new ReturnCode();
            returnCode.CodeText = sb;
            returnCode.FileName = txtFileName + "Add.js";
            returnCode.CodeType = "HTML";
            return returnCode;
        }
        #endregion

        #region 其他
        /// <summary>
        /// 获得拼接的SQL语句
        /// </summary>
        /// <param name="mainTableAlias">主表的别名</param>
        /// <param name="gv_Cols">选择字段的GridView</param>
        /// <param name="gv_SubTable">主表关联表的GridView</param>
        /// <param name="isCount">select后面是否为Count(*)</param>
        /// <returns></returns>
        public string GetSqlString(string mainTableAlias, DataGridView gv_Cols, DataGridView gv_SubTable, bool isCount = false)
        {
            string sql = "		SELECT ";

            if (isCount)
            {
                sql += " count(*) ";
            }
            else
            {
                //拼接主键.
                foreach (IColumn col in _tbl.PrimaryKey.Columns)
                {
                    sql += mainTableAlias + "." + col.ColumnName + ",";
                }
                //拼接选择的列
                foreach (DataGridViewRow row in gv_Cols.Rows)
                {
                    if (row.Cells["col_Select"].Value.ToString() == "True")
                    {
                        if (row.Cells["col_IsCode"].Value != null && row.Cells["col_IsCode"].Value.ToString() == "True")
                        {
                            sql += "(" + string.Format(_dataAccess.CodeSQL, row.Cells["col_Code"].Value.ToString(), row.Cells["col_TableAlias"].Value.ToString() + "." + row.Cells["col_Field"].Value.ToString()) + ")  As " + row.Cells["col_Alias"].Value.ToString() + ",";
                        }
                        else
                        {
                            sql += row.Cells["col_TableAlias"].Value.ToString() + "." + row.Cells["col_Field"].Value.ToString() + " As " + row.Cells["col_Alias"].Value.ToString() + ",";
                        }
                    }
                }

                sql = sql.Substring(0, sql.Length - 1);
            }

            sql += "\r\n		FROM " + _tbl.TableName + " " + mainTableAlias + " ";

            foreach (DataGridViewRow row in gv_SubTable.Rows)
            {
                if (row.Cells[0].Value.ToString() == "True")
                {
                    if (row.Cells[5].Value != null && row.Cells[5].Value.ToString() != "")
                    {
                        sql += "\r\n			" + row.Cells[1].Value.ToString().ToString() + " " + row.Cells[5].Value.ToString() + " " + row.Cells[3].Value.ToString() + " " + row.Cells[4].Value.ToString();
                    }
                    else
                    {
                        sql += "\r\n			" + row.Cells[1].Value.ToString().ToString() + " " + row.Cells[2].Value.ToString() + " " + row.Cells[3].Value.ToString() + " " + row.Cells[4].Value.ToString();
                    }
                }
            }

            return sql;
        }

        /// <summary>
        /// 获得Xml文件SQLWhere 条件字符串
        /// </summary>
        /// <param name="gv_ColsWhere">选择条件的GridView</param>
        /// <returns></returns>
        public string GetXmlSqlWhereString(DataGridView gv_ColsWhere)
        {
            if (gv_ColsWhere == null || gv_ColsWhere.Rows.Count == 0) return "";

            StringBuilder sb = new StringBuilder();
            int i = 0;
            sb.AppendLine("		<where>");
            foreach (DataGridViewRow row in gv_ColsWhere.Rows)
            {
                // 如果不显示,但选中了,判断是否己赋值,如己赋值,在SQL语句中拼上,没赋值,拼上属性
                if (row.Cells[0].Value.ToString() == "True")
                {
                    IColumn col = GetColByName(row.Cells[5].Value.ToString(), row.Cells[3].Value.ToString());

                    if (_dataAccess.DataBaseType == "ORACLE")
                    {
                        if (col.DataType.DbDataType.ToUpper() == "DATE")
                        {
                            sb.AppendLine("			<if test=\"" + OneStringLower(col.PascalName) + " != null and " + OneStringLower(col.PascalName) + " != ''\">");
                            sb.AppendLine("				 AND " + col.ColumnName.ToUpper() + " = TO_DATE(#{" + OneStringLower(col.PascalName) + "},'YYYY-MM-DD HH24:MI:SS')");
                            sb.AppendLine("			</if>");
                        }
                        else if (col.DataType.DbDataType.ToUpper() == "NUMBER" || col.DataType.DbDataType.ToUpper() == "INTEGER")
                        {
                            sb.AppendLine("		    <if test=\"(" + OneStringLower(col.PascalName) + " != null and " + OneStringLower(col.PascalName) + " != '') or " + OneStringLower(col.PascalName) + " == 0\">");
                            sb.AppendLine("			 	 AND " + col.ColumnName.ToUpper() + " = #{" + OneStringLower(col.PascalName) + "}");
                            sb.AppendLine("		    </if>");
                        }
                        else
                        {
                            sb.AppendLine("			<if test=\"" + OneStringLower(col.PascalName) + " != null and " + OneStringLower(col.PascalName) + " != ''\">");
                            sb.AppendLine("				 AND " + col.ColumnName.ToUpper() + " = #{" + OneStringLower(col.PascalName) + "}");
                            sb.AppendLine("			</if>");
                        }
                    }
                    if (_dataAccess.DataBaseType == "SQLSERVER")
                    {
                        if (col.DataType.DbDataType.ToUpper() == "DECIMAL" || col.DataType.DbDataType.ToUpper() == "INT" || col.DataType.DbDataType.ToUpper() == "FLOAT" || col.DataType.DbDataType.ToUpper() == "MONEY" || col.DataType.DbDataType.ToUpper() == "NUMERIC")
                        {
                            sb.AppendLine("		    <if test=\"(" + OneStringLower(col.PascalName) + " != null and " + OneStringLower(col.PascalName) + " != '') or " + OneStringLower(col.PascalName) + " == 0\">");
                            sb.AppendLine("			 	 AND " + col.ColumnName.ToUpper() + " = #{" + OneStringLower(col.PascalName) + "}");
                            sb.AppendLine("		    </if>");
                        }
                        else
                        {
                            sb.AppendLine("			<if test=\"" + OneStringLower(col.PascalName) + " != null and " + OneStringLower(col.PascalName) + " != ''\">");
                            sb.AppendLine("				 AND " + col.ColumnName.ToUpper() + " = #{" + OneStringLower(col.PascalName) + "}");
                            sb.AppendLine("			</if>");
                        }
                    }
                    if (_dataAccess.DataBaseType == "MYSQL")
                    {
                        if (col.DataType.DbDataType.ToUpper() == "DECIMAL" || col.DataType.DbDataType.ToUpper() == "INTEGER" || col.DataType.DbDataType.ToUpper() == "INT" || col.DataType.DbDataType.ToUpper() == "FLOAT" || col.DataType.DbDataType.ToUpper() == "DOUBLE")
                        {
                            sb.AppendLine("		    <if test=\"(" + OneStringLower(col.PascalName) + " != null and " + OneStringLower(col.PascalName) + " != '') or " + OneStringLower(col.PascalName) + " == 0\">");
                            sb.AppendLine("			 	 AND " + col.ColumnName.ToUpper() + " = #{" + OneStringLower(col.PascalName) + "}");
                            sb.AppendLine("		    </if>");
                        }
                        else
                        {
                            sb.AppendLine("			<if test=\"" + OneStringLower(col.PascalName) + " != null and " + OneStringLower(col.PascalName) + " != ''\">");
                            sb.AppendLine("				 AND " + col.ColumnName.ToUpper() + " = #{" + OneStringLower(col.PascalName) + "}");
                            sb.AppendLine("			</if>");
                        }
                    }
                }
            }
            sb.AppendLine("		</where>");

            return sb.ToString();
        }

        #endregion

        #region private

        /// <summary>
        /// 将字段的首字母变成小写，其他驼峰命名规则
        /// </summary>
        /// <param name="colname"></param>
        /// <returns></returns>
        private string OneStringLower(string colname)
        {
            string newcolname = "";
            newcolname = colname.Substring(0, 1).ToLower();
            newcolname += colname.Substring(1, colname.Length - 1);
            return newcolname;
        }

        /// <summary>
        /// 去掉表格中的T然后首字母大写.
        /// </summary>
        /// <returns></returns>
        private string GetewPascalName()
        {
            //去掉表名中的第一个 T
            string NewPascalName = "";
            if (_tbl.PascalName.IndexOf('T') == 0)
            {
                NewPascalName = _tbl.PascalName.Substring(1, _tbl.PascalName.Length - 1);
            }
            else { NewPascalName = _tbl.PascalName; }
            return NewPascalName;
        }

        private string Lower()
        {
            string str = GetewPascalName();
            string newStr = string.Empty;

            if (str.Length > 0)
            {
                newStr = str.Substring(0, 1).ToLower() + str.Substring(1);
            }
            return newStr;
        }

        /// <summary>
        /// 根据表名和列表得到IColumn对象.
        /// </summary>
        /// <param name="tableName"></param>
        /// <param name="colName"></param>
        /// <returns></returns>
        private IColumn GetColByName(string tableName, string colName)
        {
            IDbTable table;
            if (tableName.ToUpper() != _tbl.TableName.ToUpper())
                table = _dataAccess.GetTableByTableName(_connectString, tableName);
            else
                table = _tbl;
            IColumn col1 = table.Columns.Find(delegate(IColumn col) { return col.ColumnName == colName; });
            return col1;
        }

        #endregion
    }
}
