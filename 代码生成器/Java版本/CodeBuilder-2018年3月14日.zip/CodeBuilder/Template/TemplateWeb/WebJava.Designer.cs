namespace Esint.Template.TemplateWeb
{
    partial class WebJava
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.button2 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.gv_Setting = new System.Windows.Forms.DataGridView();
            this.cbx_Cols = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.txt_ControlName = new System.Windows.Forms.TextBox();
            this.ColName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.C1 = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.C2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.C3 = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.c5 = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.C4 = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.Column1 = new System.Windows.Forms.DataGridViewComboBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.gv_Setting)).BeginInit();
            this.SuspendLayout();
            // 
            // button2
            // 
            this.button2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.button2.Location = new System.Drawing.Point(1028, 92);
            this.button2.Margin = new System.Windows.Forms.Padding(4);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(100, 29);
            this.button2.TabIndex = 3;
            this.button2.Text = "取消";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button1
            // 
            this.button1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.button1.Location = new System.Drawing.Point(1028, 45);
            this.button1.Margin = new System.Windows.Forms.Padding(4);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(100, 29);
            this.button1.TabIndex = 4;
            this.button1.Text = "确定";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // gv_Setting
            // 
            this.gv_Setting.AllowDrop = true;
            this.gv_Setting.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.gv_Setting.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.gv_Setting.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.gv_Setting.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.ColName,
            this.C1,
            this.C2,
            this.C3,
            this.c5,
            this.C4,
            this.Column1});
            this.gv_Setting.Location = new System.Drawing.Point(16, 45);
            this.gv_Setting.Margin = new System.Windows.Forms.Padding(4);
            this.gv_Setting.Name = "gv_Setting";
            this.gv_Setting.RowTemplate.Height = 23;
            this.gv_Setting.Size = new System.Drawing.Size(995, 612);
            this.gv_Setting.TabIndex = 5;
            this.gv_Setting.CellMouseDown += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.gv_Setting_CellMouseDown);
            this.gv_Setting.CellMouseMove += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.gv_Setting_CellMouseMove);
            this.gv_Setting.CellValueChanged += new System.Windows.Forms.DataGridViewCellEventHandler(this.gv_Setting_CellValueChanged);
            this.gv_Setting.DataError += new System.Windows.Forms.DataGridViewDataErrorEventHandler(this.gv_Setting_DataError);
            this.gv_Setting.SelectionChanged += new System.EventHandler(this.gv_Setting_SelectionChanged);
            this.gv_Setting.DragDrop += new System.Windows.Forms.DragEventHandler(this.gv_Setting_DragDrop);
            this.gv_Setting.DragEnter += new System.Windows.Forms.DragEventHandler(this.gv_Setting_DragEnter);
            // 
            // cbx_Cols
            // 
            this.cbx_Cols.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.cbx_Cols.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbx_Cols.FormattingEnabled = true;
            this.cbx_Cols.Items.AddRange(new object[] {
            "一列",
            "二列",
            "三列",
            "四列"});
            this.cbx_Cols.Location = new System.Drawing.Point(1027, 160);
            this.cbx_Cols.Margin = new System.Windows.Forms.Padding(4);
            this.cbx_Cols.Name = "cbx_Cols";
            this.cbx_Cols.Size = new System.Drawing.Size(101, 23);
            this.cbx_Cols.TabIndex = 6;
            this.cbx_Cols.SelectedIndexChanged += new System.EventHandler(this.cbx_Cols_SelectedIndexChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(17, 16);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(82, 15);
            this.label1.TabIndex = 8;
            this.label1.Text = "控件名称：";
            // 
            // txt_ControlName
            // 
            this.txt_ControlName.Location = new System.Drawing.Point(107, 9);
            this.txt_ControlName.Margin = new System.Windows.Forms.Padding(4);
            this.txt_ControlName.Name = "txt_ControlName";
            this.txt_ControlName.Size = new System.Drawing.Size(277, 25);
            this.txt_ControlName.TabIndex = 9;
            // 
            // ColName
            // 
            this.ColName.Frozen = true;
            this.ColName.HeaderText = "Column1";
            this.ColName.Name = "ColName";
            this.ColName.ReadOnly = true;
            this.ColName.Visible = false;
            // 
            // C1
            // 
            this.C1.Frozen = true;
            this.C1.HeaderText = "选择";
            this.C1.Name = "C1";
            this.C1.Width = 40;
            // 
            // C2
            // 
            this.C2.Frozen = true;
            this.C2.HeaderText = "B标签含义";
            this.C2.Name = "C2";
            // 
            // C3
            // 
            this.C3.Frozen = true;
            this.C3.HeaderText = "控件";
            this.C3.Items.AddRange(new object[] {
            "W文本框",
            "X下拉框",
            "R日期框",
            "Y隐藏域"});
            this.C3.Name = "C3";
            // 
            // c5
            // 
            this.c5.DisplayStyle = System.Windows.Forms.DataGridViewComboBoxDisplayStyle.Nothing;
            this.c5.Frozen = true;
            this.c5.HeaderText = "代码项";
            this.c5.MaxDropDownItems = 30;
            this.c5.Name = "c5";
            this.c5.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.c5.Width = 150;
            // 
            // C4
            // 
            this.C4.Frozen = true;
            this.C4.HeaderText = "必填";
            this.C4.Name = "C4";
            // 
            // Column1
            // 
            this.Column1.Frozen = true;
            this.Column1.HeaderText = "跨列";
            this.Column1.Items.AddRange(new object[] {
            "一列"});
            this.Column1.Name = "Column1";
            // 
            // WebJava
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1144, 670);
            this.Controls.Add(this.txt_ControlName);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.cbx_Cols);
            this.Controls.Add(this.gv_Setting);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "WebJava";
            this.Text = "Web";
            ((System.ComponentModel.ISupportInitialize)(this.gv_Setting)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.DataGridView gv_Setting;
        private System.Windows.Forms.ComboBox cbx_Cols;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txt_ControlName;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColName;
        private System.Windows.Forms.DataGridViewCheckBoxColumn C1;
        private System.Windows.Forms.DataGridViewTextBoxColumn C2;
        private System.Windows.Forms.DataGridViewComboBoxColumn C3;
        private System.Windows.Forms.DataGridViewComboBoxColumn c5;
        private System.Windows.Forms.DataGridViewCheckBoxColumn C4;
        private System.Windows.Forms.DataGridViewComboBoxColumn Column1;

    }
}