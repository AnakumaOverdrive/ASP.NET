﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Esint.CodeBuilder.InterFace;
using Esint.TemplateCommon;

namespace Esint.Template.TemplateWeb
{
    public partial class WebListJava2 : Form, ITemplate
    {
        #region 模板接口

        //生成代码的主表
        public IDbTable Tbl { get; set; }

        //表空间
        public string NameSpace { get; set; }

        //文件名
        public string FileName { get; set; }

        //代码类型列表
        public List<ICodeType> CodeTypeList { get; set; }

        // 操作者姓名
        public string OperName { get; set; }

        //连接字符串
        public string ConnectString { get; set; }

        // 数据访问类
        public ICodeBuilder DataAccess { get; set; }

        // 表列表(用于多表生成)
        public List<IDbTable> Tbls { get; set; }

        // 是否打包生成(即是否批量生成)
        public bool IsPackage { get; set; }

        //程序名称(为名称空间指定名称时使用，因为bll和dal层是不能全称的。)
        public string AppName { get; set; }

        //模板提供对象
        WebListJava2Template TemplateProvide;
        #endregion

        #region 窗口控制

        #region 局部变量
        //
        // 局部变量
        //  
        private int selectionIdx;       // 行拖动时,当前拖动的行号
        private string oldTablesAlias;  // 原表的别名,用于批量修改别名
        private string oldsubAlias;     // 原子表的别名.
        private bool fieldsReload;      // 字段列表是否重新加载,当选择第一个B标签后,会重新加载字段列表(该变量为True)
        private bool whereReload;       // 条件列表是否重新加载,当选择第一个B标签后,会重新加载字段列表(该变量为True)
        #endregion

        #region 初始化窗口

        //
        // 初始化窗口
        //
        public WebListJava2()
        {
            InitializeComponent();
        }

        /// <summary>
        /// 初始化设置窗口
        /// </summary>
        public void Initi()
        {
            fieldsReload = true; // 初始时,设置需要重新加载字段列表
            whereReload = true;  // 初始时,设置需要重新加载条件列表

            // 判断主数据表是否为空,如果为空,则提示错误
            if (Tbl == null)
            {
                MessageBox.Show("没有获取到数据表！", "错误");
                return;
            }

            lbl_MasterTableName.Text = Tbl.TableName;  // 设置主表显示表名
            txt_MainTableAlias.Text = Tbl.TableName;   //默认别名为表名
            oldTablesAlias = Tbl.TableName;            //修改前别名也为表名

            //
            // 根据主表的外键列表,初始化外键关联表
            //
            foreach (IForeignKeyClass fk in Tbl.ForeignKeys)
            {
                string onWhere = "ON ";
                int i = 0;
                foreach (IForeignKeyColumn fkc in fk.FKColumns)
                {
                    if (i == 0)
                        onWhere += fkc.PKTableName + "." + fkc.PKColumnName + "= " + fkc.FKTableName + "." + fkc.FKColumnName;
                    else
                        onWhere += " And " + fkc.PKTableName + "." + fkc.PKColumnName + "= " + fkc.FKTableName + "." + fkc.FKColumnName;
                    i++;
                }
                gv_SubTable.Rows.Add(new object[] { false, "Inner Join", fk.FKColumns[0].FKTableName, fk.FKColumns[0].FKTableName, onWhere });
            }

            //
            // 设置文件名
            // 
            txt_FileName.Text = String.Format(FileName, GetewPascalName());
            //
            // 设置事件事先选中
            //
            checkedListBox1.SetItemChecked(0, true);
            checkedListBox1.SetItemChecked(1, true);

            //初始化模板提供对象.
            TemplateProvide = new WebListJava2Template(Tbl, NameSpace, FileName, CodeTypeList, OperName, ConnectString, DataAccess, Tbls, IsPackage, AppName);
        }
        #endregion

        /// <summary>
        /// 新增数据表按钮事件
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btn_AddTable_Click(object sender, EventArgs e)
        {
            Esint.TemplateCommon.SelectLinkTable select_Table_Form = new Esint.TemplateCommon.SelectLinkTable(DataAccess, ConnectString);

            Dictionary<string, string> stbs = new Dictionary<string, string>();

            foreach (DataGridViewRow row in gv_SubTable.Rows)
            {
                if (row.Cells[0].EditedFormattedValue.ToString() == "True")
                    stbs.Add(row.Cells[3].EditedFormattedValue.ToString(), row.Cells[2].EditedFormattedValue.ToString());//添加选中的子表
            }

            stbs.Add(txt_MainTableAlias.Text, Tbl.TableName);//添加主表

            select_Table_Form.Tables = stbs;
            select_Table_Form.ShowDialog();
            gv_SubTable.Rows.Add(new object[] { true, select_Table_Form.JoinType, select_Table_Form.SubTableName, select_Table_Form.SubAlias, select_Table_Form.OnWhere, select_Table_Form.FilterStr });
        }

        /// <summary>
        /// B标签改变事件
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void tabControl1_SelectedIndexChanged(object sender, EventArgs e)
        {
            switch (tabControl1.SelectedIndex)
            {
                case 0:
                    // 当选择了第一个选项卡后,要求重新加载字段和条件列表
                    fieldsReload = true;
                    whereReload = true;
                    break;

                case 1:
                    // 判断是否需要重新加载 字段 列表,加载后,将是否需要加载设置为false;
                    if (fieldsReload == false)
                        break;
                    else
                        fieldsReload = false;
                    //
                    // 重新加载列表
                    //
                    gv_Cols.Rows.Clear();
                    // IDbTable db = DataAccess.GetTableByTableName(ConnectString, Tbl.TableName);

                    //对列表字段Grid进行赋值.
                    foreach (IColumn col in this.Tbl.Columns)
                    {
                        gv_Cols.Rows.Add(new object[] { false, false, col.Description, col.ColumnName, col.ColumnName, Tbl.TableName, txt_MainTableAlias.Text });
                    }
                    foreach (DataGridViewRow row in gv_SubTable.Rows)
                    {
                        if (row.Cells[0].EditedFormattedValue.ToString() == "True")
                        {
                            string tableName = row.Cells[2].EditedFormattedValue.ToString();
                            IDbTable db = DataAccess.GetTableByTableName(ConnectString, tableName);
                            foreach (IColumn col in db.Columns)
                            {
                                gv_Cols.Rows.Add(new object[] { false, false, col.Description, col.ColumnName, col.ColumnName, tableName, row.Cells[3].EditedFormattedValue.ToString() });
                            }
                        }
                    }

                    break;
                case 2:
                    // 判断是否需要重新加载 条件 列表,加载后,将是否需要加载设置为false;
                    if (whereReload == false)
                        break;
                    else
                        whereReload = false;

                    //
                    // 重新加载列表
                    //
                    gv_ColsWhere.Rows.Clear();

                    // IDbTable db1 = DataAccess.GetTableByTableName(ConnectString, Tbl.TableName);
                    foreach (IColumn col in Tbl.Columns)
                    {
                        if (col.DataType.CSharpType == "DateTime" || col.DataType.CSharpType == "DateTime?" || col.DataType.CSharpType == "Timestamp" || col.DataType.CSharpType == "Timestamp?")
                            gv_ColsWhere.Rows.Add(new object[] { false, false, col.Description, col.ColumnName, txt_MainTableAlias.Text, Tbl.TableName, "=", "", "R日期框", "" });
                        else
                            gv_ColsWhere.Rows.Add(new object[] { false, false, col.Description, col.ColumnName, txt_MainTableAlias.Text, Tbl.TableName, "=", "", "W文本框", "" });
                    }
                    foreach (DataGridViewRow row in gv_SubTable.Rows)
                    {
                        if (row.Cells[0].EditedFormattedValue.ToString() == "True")
                        {
                            string tableName = row.Cells[2].EditedFormattedValue.ToString();
                            string aliasName = row.Cells[3].EditedFormattedValue.ToString();
                            IDbTable db1 = DataAccess.GetTableByTableName(ConnectString, tableName);
                            foreach (IColumn col in db1.Columns)
                            {
                                if (col.DataType.CSharpType == "DateTime" || col.DataType.CSharpType == "DateTime?" || col.DataType.CSharpType == "Timestamp" || col.DataType.CSharpType == "Timestamp?")
                                    gv_ColsWhere.Rows.Add(new object[] { false, false, col.Description, col.ColumnName, aliasName, tableName, "=", "", "R日期框", "" });
                                else
                                    gv_ColsWhere.Rows.Add(new object[] { false, false, col.Description, col.ColumnName, aliasName, tableName, "=", "", "W文本框", "" });
                            }
                        }
                    }
                    break;
                case 3:
                    // SQL语句
                    txt_SqlText.Text = TemplateProvide.GetSqlString(txt_MainTableAlias.Text, gv_Cols, gv_SubTable);
                    break;
            }
        }

        /// <summary>
        /// 条件列表选择值改变事件
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void gv_ColsWhere_CellValueChanged(object sender, DataGridViewCellEventArgs e)
        {
            // 如果
            if (e.ColumnIndex == 8 && e.RowIndex != -1 && !gv_ColsWhere.Rows[e.RowIndex].IsNewRow && gv_ColsWhere.Rows[e.RowIndex].Cells[8].Value.ToString() == "X下拉框")
            {
                ((DataGridViewComboBoxCell)this.gv_ColsWhere.CurrentRow.Cells[9]).DataSource = CodeTypeList;
                ((DataGridViewComboBoxCell)this.gv_ColsWhere.CurrentRow.Cells[9]).DisplayMember = "Meaning";
                ((DataGridViewComboBoxCell)this.gv_ColsWhere.CurrentRow.Cells[9]).ValueMember = "Flag";
            }

            if (e.ColumnIndex == 0)
            {
                gv_ColsWhere.Sort(gv_ColsWhere.Columns[0], ListSortDirection.Descending);
            }
        }

        private void txt_MainTableAlias_TextChanged(object sender, EventArgs e)
        {
            foreach (DataGridViewRow row in gv_SubTable.Rows)
            {
                row.Cells[4].Value = row.Cells[4].EditedFormattedValue.ToString().Replace(" " + oldTablesAlias + ".", " " + txt_MainTableAlias.Text.Trim() + "."); //替换别名
            }
            oldTablesAlias = txt_MainTableAlias.Text;
        }

        private void gv_SubTable_CellEndEdit(object sender, DataGridViewCellEventArgs e)
        {
            if (e.ColumnIndex == 3)
            {
                gv_SubTable.Rows[e.RowIndex].Cells[4].Value = gv_SubTable.Rows[e.RowIndex].Cells[4].Value.ToString().Replace(" " + oldsubAlias + ".", " " + gv_SubTable.Rows[e.RowIndex].Cells[e.ColumnIndex].Value + "."); //替换别名
            }
        }

        private void gv_SubTable_CellBeginEdit(object sender, DataGridViewCellCancelEventArgs e)
        {
            if (e.ColumnIndex == 3)
            {
                oldsubAlias = gv_SubTable.Rows[e.RowIndex].Cells[e.ColumnIndex].Value.ToString();
            }
        }

        private void gv_ColsWhere_CellEndEdit(object sender, DataGridViewCellEventArgs e)
        {
            if (e.ColumnIndex == 0 && e.RowIndex >= 0)
            {
                if (gv_ColsWhere.Rows[e.RowIndex].Cells[0].Value.ToString() == "True")
                {
                    gv_ColsWhere.Rows[e.RowIndex].Cells[1].Value = "True";
                    gv_ColsWhere.Rows[e.RowIndex].Cells[6].Value = "=";
                }
                else
                {
                    gv_ColsWhere.Rows[e.RowIndex].Cells[1].Value = "False";
                    gv_ColsWhere.Rows[e.RowIndex].Cells[6].Value = "";
                }
            }
        }

        private void btn_BuilderCode_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        #endregion

        /// <summary>
        /// 获得Code代码
        /// </summary>
        /// <returns></returns>
        public IReturnCode[] GetCode()
        {
            if (!IsPackage)
            {
                Initi();
                this.ShowDialog();
            }


            IReturnCode[] returnCode = new IReturnCode[7];

            returnCode[0] = TemplateProvide.GetMapperXml(txt_FileName.Text, txt_MainTableAlias.Text, gv_Cols, gv_SubTable,
            gv_ColsWhere, cbx_IsWhere.Checked);
            returnCode[1] = TemplateProvide.GetMapperJava(txt_FileName.Text);
            returnCode[2] = TemplateProvide.GetServiceJava(txt_FileName.Text);
            returnCode[3] = TemplateProvide.GetServiceImpJava(txt_FileName.Text);
            returnCode[4] = TemplateProvide.GetControllerJava(txt_FileName.Text);

            returnCode[5] = TemplateProvide.GetPageJsp(txt_FileName.Text, cbx_IsWhere.Checked, cbx_IsQuery.Checked, cbx_IsEdit.Checked, cbx_IsDelete.Checked, cbx_IsCheck.Checked, cbx_IsNum.Checked, cbx_Page.Checked, txt_PageSize.Text,gv_Cols, gv_SubTable, gv_ColsWhere);
            returnCode[6] = TemplateProvide.GetPageJavaScript(txt_FileName.Text, cbx_IsWhere.Checked, cbx_IsQuery.Checked, cbx_IsEdit.Checked, cbx_IsDelete.Checked, cbx_IsCheck.Checked, cbx_IsNum.Checked, cbx_Page.Checked, txt_PageSize.Text, gv_Cols, gv_SubTable, gv_ColsWhere);

            return returnCode;
        }

        #region 列 列表排序方法

        private void gv_Cols_CellMouseMove(object sender, DataGridViewCellMouseEventArgs e)
        {
            if ((e.Clicks < 2) && (e.Button == MouseButtons.Left))
            {
                if ((e.ColumnIndex == -1) && (e.RowIndex > -1))
                    gv_Cols.DoDragDrop(gv_Cols.Rows[e.RowIndex], DragDropEffects.Move);
            }
        }

        private void gv_Cols_DragDrop(object sender, DragEventArgs e)
        {
            MoveRow(gv_Cols, e);
        }

        private void gv_Cols_CellMouseDown(object sender, DataGridViewCellMouseEventArgs e)
        {
            if (e.RowIndex >= 0)
                selectionIdx = e.RowIndex;

        }

        private void gv_Cols_SelectionChanged(object sender, EventArgs e)
        {

            SelectionChanged(gv_Cols);
        }

        private void gv_Cols_DragEnter(object sender, DragEventArgs e)
        {
            e.Effect = DragDropEffects.Move;
        }


        private void gv_Cols_CellValueChanged(object sender, DataGridViewCellEventArgs e)
        {
            if (e.ColumnIndex == 0)
            {

                gv_Cols.Sort(gv_Cols.Columns[0], ListSortDirection.Descending);
            }

            if (this.gv_Cols.CurrentRow != null && e.ColumnIndex == 7)
            {
                if (((DataGridViewCheckBoxCell)gv_Cols.CurrentRow.Cells[7]).Value.ToString() == "True")
                {
                    ((DataGridViewComboBoxCell)this.gv_Cols.CurrentRow.Cells[8]).DataSource = CodeTypeList;
                    ((DataGridViewComboBoxCell)this.gv_Cols.CurrentRow.Cells[8]).DisplayMember = "Meaning";
                    ((DataGridViewComboBoxCell)this.gv_Cols.CurrentRow.Cells[8]).ValueMember = "Flag";

                }
                else
                {
                    ((DataGridViewComboBoxCell)this.gv_Cols.CurrentRow.Cells[8]).Value = "";
                    // ((DataGridViewComboBoxCell)this.gv_Cols.CurrentRow.Cells[6]).Items.Clear();
                }
            }

        }
        #endregion

        #region 条件列表排序

        private void gv_ColsWhere_CellMouseDown(object sender, DataGridViewCellMouseEventArgs e)
        {
            if (e.RowIndex >= 0)
                selectionIdx = e.RowIndex;
        }

        private void gv_ColsWhere_CellMouseMove(object sender, DataGridViewCellMouseEventArgs e)
        {
            if ((e.Clicks < 2) && (e.Button == MouseButtons.Left))
            {
                if ((e.ColumnIndex == -1) && (e.RowIndex > -1))
                    gv_ColsWhere.DoDragDrop(gv_ColsWhere.Rows[e.RowIndex], DragDropEffects.Move);

            }
        }

        private void gv_ColsWhere_DragDrop(object sender, DragEventArgs e)
        {
            MoveRow(gv_ColsWhere, e);
        }

        private void gv_ColsWhere_DragEnter(object sender, DragEventArgs e)
        {
            e.Effect = DragDropEffects.Move;
        }

        private void gv_ColsWhere_SelectionChanged(object sender, EventArgs e)
        {
            SelectionChanged(gv_ColsWhere);
        }
        #endregion

        #region 排序公共方法

        public void MoveRow(DataGridView gv, DragEventArgs e)
        {
            int idx = GetRowFromPoint(gv, e.X, e.Y);
            if (idx < 0) return;
            if (e.Data.GetDataPresent(typeof(DataGridViewRow)))
            {
                DataGridViewRow row = (DataGridViewRow)e.Data.GetData(typeof(DataGridViewRow));
                gv.Rows.Remove(row);
                gv.Rows.Insert(idx, row);
                selectionIdx = idx;
            }
        }

        public void SelectionChanged(DataGridView gv)
        {
            if ((gv.Rows.Count > 0) && (gv.SelectedRows.Count > 0) && (gv.SelectedRows[0].Index != selectionIdx))
            {
                if (gv.Rows.Count <= selectionIdx)
                    selectionIdx = gv.Rows.Count - 1;
                gv.Rows[selectionIdx].Selected = true;
                gv.CurrentCell = gv.Rows[selectionIdx].Cells[0];
            }
        }

        private int GetRowFromPoint(DataGridView gv, int x, int y)
        {
            for (int i = 0; i < gv.RowCount; i++)
            {
                Rectangle rec = gv.GetRowDisplayRectangle(i, false);

                if (gv.RectangleToScreen(rec).Contains(x, y))
                    return i;
            }
            return -1;
        }
        #endregion

        #region SQL复制功能

        /// <summary>
        /// SQL语句复制功能.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btn_copy_Click(object sender, EventArgs e)
        {
            Clipboard.SetDataObject(txt_SqlText.Text);
        }

        #endregion

        #region private

        /// <summary>
        /// 去掉表格中的T然后首字母大写.
        /// </summary>
        /// <returns></returns>
        private string GetewPascalName()
        {
            //去掉表名中的第一个 T
            string NewPascalName = "";
            if (Tbl.PascalName.IndexOf('T') == 0)
            {
                NewPascalName = Tbl.PascalName.Substring(1, Tbl.PascalName.Length - 1);
            }
            else { NewPascalName = Tbl.PascalName; }
            return NewPascalName;
        }

        #endregion
    }
}
