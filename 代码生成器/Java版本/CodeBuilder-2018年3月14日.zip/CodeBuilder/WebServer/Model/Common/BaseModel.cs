﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Esint.Common.Model;

namespace Esint.CodeSite.Model
{
    [Serializable]
    public class BaseModel : RootModel
    {
       
    }
}
