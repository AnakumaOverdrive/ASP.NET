﻿namespace Esint.CodeBuilder.Forms
{
    partial class ConnectForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_close = new System.Windows.Forms.Button();
            this.btn_Connect = new System.Windows.Forms.Button();
            this.cbx_DataBaseType = new System.Windows.Forms.ComboBox();
            this.lbl_DBType = new System.Windows.Forms.Label();
            this.pan_Sql = new System.Windows.Forms.Panel();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.btn_SqlCheckConn = new System.Windows.Forms.Button();
            this.txt_SqlPassWord = new System.Windows.Forms.TextBox();
            this.txt_SqlDbName = new System.Windows.Forms.TextBox();
            this.txt_SqlUserName = new System.Windows.Forms.TextBox();
            this.txt_ServerAddr = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.pan_MySql = new System.Windows.Forms.Panel();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.btn_MySqlCheckConn = new System.Windows.Forms.Button();
            this.txt_MySqlPassWord = new System.Windows.Forms.TextBox();
            this.txt_MySqlDbName = new System.Windows.Forms.TextBox();
            this.txt_MySqlUserName = new System.Windows.Forms.TextBox();
            this.txt_MySqlAddr = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.pan_Oracle = new System.Windows.Forms.Panel();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.btn_CheckOraConn = new System.Windows.Forms.Button();
            this.txt_serviceName = new System.Windows.Forms.TextBox();
            this.txt_password = new System.Windows.Forms.TextBox();
            this.txt_UserName = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.pan_Sql.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.pan_MySql.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.pan_Oracle.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // btn_close
            // 
            this.btn_close.Location = new System.Drawing.Point(355, 284);
            this.btn_close.Name = "btn_close";
            this.btn_close.Size = new System.Drawing.Size(75, 23);
            this.btn_close.TabIndex = 19;
            this.btn_close.Text = "取消";
            this.btn_close.UseVisualStyleBackColor = true;
            this.btn_close.Click += new System.EventHandler(this.btn_close_Click);
            // 
            // btn_Connect
            // 
            this.btn_Connect.Location = new System.Drawing.Point(274, 284);
            this.btn_Connect.Name = "btn_Connect";
            this.btn_Connect.Size = new System.Drawing.Size(75, 23);
            this.btn_Connect.TabIndex = 18;
            this.btn_Connect.Text = "确定";
            this.btn_Connect.UseVisualStyleBackColor = true;
            this.btn_Connect.Click += new System.EventHandler(this.btn_Connect_Click);
            // 
            // cbx_DataBaseType
            // 
            this.cbx_DataBaseType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbx_DataBaseType.FormattingEnabled = true;
            this.cbx_DataBaseType.Items.AddRange(new object[] {
            "Oracle",
            "SqlServer",
            "MySql"});
            this.cbx_DataBaseType.Location = new System.Drawing.Point(133, 29);
            this.cbx_DataBaseType.Name = "cbx_DataBaseType";
            this.cbx_DataBaseType.Size = new System.Drawing.Size(240, 20);
            this.cbx_DataBaseType.TabIndex = 1;
            this.cbx_DataBaseType.SelectedIndexChanged += new System.EventHandler(this.cbx_DataBaseType_SelectedIndexChanged);
            // 
            // lbl_DBType
            // 
            this.lbl_DBType.AutoSize = true;
            this.lbl_DBType.Location = new System.Drawing.Point(50, 32);
            this.lbl_DBType.Name = "lbl_DBType";
            this.lbl_DBType.Size = new System.Drawing.Size(77, 12);
            this.lbl_DBType.TabIndex = 2;
            this.lbl_DBType.Text = "数据库类型：";
            // 
            // pan_Sql
            // 
            this.pan_Sql.Controls.Add(this.groupBox2);
            this.pan_Sql.Location = new System.Drawing.Point(35, 67);
            this.pan_Sql.Name = "pan_Sql";
            this.pan_Sql.Size = new System.Drawing.Size(373, 197);
            this.pan_Sql.TabIndex = 11;
            this.pan_Sql.Visible = false;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.btn_SqlCheckConn);
            this.groupBox2.Controls.Add(this.txt_SqlPassWord);
            this.groupBox2.Controls.Add(this.txt_SqlDbName);
            this.groupBox2.Controls.Add(this.txt_SqlUserName);
            this.groupBox2.Controls.Add(this.txt_ServerAddr);
            this.groupBox2.Controls.Add(this.label7);
            this.groupBox2.Controls.Add(this.label6);
            this.groupBox2.Controls.Add(this.label5);
            this.groupBox2.Controls.Add(this.label4);
            this.groupBox2.Location = new System.Drawing.Point(3, 9);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(367, 179);
            this.groupBox2.TabIndex = 13;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "建立SQLServer数据库";
            // 
            // btn_SqlCheckConn
            // 
            this.btn_SqlCheckConn.Location = new System.Drawing.Point(263, 146);
            this.btn_SqlCheckConn.Name = "btn_SqlCheckConn";
            this.btn_SqlCheckConn.Size = new System.Drawing.Size(75, 23);
            this.btn_SqlCheckConn.TabIndex = 6;
            this.btn_SqlCheckConn.Text = "测试连接";
            this.btn_SqlCheckConn.UseVisualStyleBackColor = true;
            this.btn_SqlCheckConn.Click += new System.EventHandler(this.btn_SqlCheckConn_Click);
            // 
            // txt_SqlPassWord
            // 
            this.txt_SqlPassWord.Location = new System.Drawing.Point(102, 119);
            this.txt_SqlPassWord.Name = "txt_SqlPassWord";
            this.txt_SqlPassWord.PasswordChar = '*';
            this.txt_SqlPassWord.Size = new System.Drawing.Size(236, 21);
            this.txt_SqlPassWord.TabIndex = 5;
            // 
            // txt_SqlDbName
            // 
            this.txt_SqlDbName.Location = new System.Drawing.Point(102, 53);
            this.txt_SqlDbName.Name = "txt_SqlDbName";
            this.txt_SqlDbName.Size = new System.Drawing.Size(236, 21);
            this.txt_SqlDbName.TabIndex = 3;
            // 
            // txt_SqlUserName
            // 
            this.txt_SqlUserName.Location = new System.Drawing.Point(102, 86);
            this.txt_SqlUserName.Name = "txt_SqlUserName";
            this.txt_SqlUserName.Size = new System.Drawing.Size(236, 21);
            this.txt_SqlUserName.TabIndex = 4;
            // 
            // txt_ServerAddr
            // 
            this.txt_ServerAddr.Location = new System.Drawing.Point(102, 20);
            this.txt_ServerAddr.Name = "txt_ServerAddr";
            this.txt_ServerAddr.Size = new System.Drawing.Size(236, 21);
            this.txt_ServerAddr.TabIndex = 2;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(19, 24);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(77, 12);
            this.label7.TabIndex = 0;
            this.label7.Text = "服务器地址：";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(19, 57);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(77, 12);
            this.label6.TabIndex = 0;
            this.label6.Text = "数据库名称：";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(43, 123);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(53, 12);
            this.label5.TabIndex = 0;
            this.label5.Text = "密  码：";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(43, 90);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(53, 12);
            this.label4.TabIndex = 0;
            this.label4.Text = "用户名：";
            // 
            // pan_MySql
            // 
            this.pan_MySql.Controls.Add(this.groupBox3);
            this.pan_MySql.Location = new System.Drawing.Point(35, 67);
            this.pan_MySql.Name = "pan_MySql";
            this.pan_MySql.Size = new System.Drawing.Size(373, 197);
            this.pan_MySql.TabIndex = 12;
            this.pan_MySql.Visible = false;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.btn_MySqlCheckConn);
            this.groupBox3.Controls.Add(this.txt_MySqlPassWord);
            this.groupBox3.Controls.Add(this.txt_MySqlDbName);
            this.groupBox3.Controls.Add(this.txt_MySqlUserName);
            this.groupBox3.Controls.Add(this.txt_MySqlAddr);
            this.groupBox3.Controls.Add(this.label11);
            this.groupBox3.Controls.Add(this.label10);
            this.groupBox3.Controls.Add(this.label9);
            this.groupBox3.Controls.Add(this.label8);
            this.groupBox3.Location = new System.Drawing.Point(3, 9);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(367, 179);
            this.groupBox3.TabIndex = 13;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "建立MySQL数据库";
            // 
            // btn_MySqlCheckConn
            // 
            this.btn_MySqlCheckConn.Location = new System.Drawing.Point(263, 146);
            this.btn_MySqlCheckConn.Name = "btn_MySqlCheckConn";
            this.btn_MySqlCheckConn.Size = new System.Drawing.Size(75, 23);
            this.btn_MySqlCheckConn.TabIndex = 6;
            this.btn_MySqlCheckConn.Text = "测试连接";
            this.btn_MySqlCheckConn.UseVisualStyleBackColor = true;
            this.btn_MySqlCheckConn.Click += new System.EventHandler(this.btn_MySqlCheckConn_Click);
            // 
            // txt_MySqlPassWord
            // 
            this.txt_MySqlPassWord.Location = new System.Drawing.Point(102, 119);
            this.txt_MySqlPassWord.Name = "txt_MySqlPassWord";
            this.txt_MySqlPassWord.PasswordChar = '*';
            this.txt_MySqlPassWord.Size = new System.Drawing.Size(236, 21);
            this.txt_MySqlPassWord.TabIndex = 5;
            // 
            // txt_MySqlDbName
            // 
            this.txt_MySqlDbName.Location = new System.Drawing.Point(102, 53);
            this.txt_MySqlDbName.Name = "txt_MySqlDbName";
            this.txt_MySqlDbName.Size = new System.Drawing.Size(236, 21);
            this.txt_MySqlDbName.TabIndex = 3;
            // 
            // txt_MySqlUserName
            // 
            this.txt_MySqlUserName.Location = new System.Drawing.Point(102, 86);
            this.txt_MySqlUserName.Name = "txt_MySqlUserName";
            this.txt_MySqlUserName.Size = new System.Drawing.Size(236, 21);
            this.txt_MySqlUserName.TabIndex = 4;
            // 
            // txt_MySqlAddr
            // 
            this.txt_MySqlAddr.Location = new System.Drawing.Point(102, 20);
            this.txt_MySqlAddr.Name = "txt_MySqlAddr";
            this.txt_MySqlAddr.Size = new System.Drawing.Size(236, 21);
            this.txt_MySqlAddr.TabIndex = 2;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(19, 24);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(77, 12);
            this.label11.TabIndex = 0;
            this.label11.Text = "服务器地址：";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(19, 57);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(77, 12);
            this.label10.TabIndex = 0;
            this.label10.Text = "数据库名称：";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(43, 123);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(53, 12);
            this.label9.TabIndex = 0;
            this.label9.Text = "密  码：";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(43, 90);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(53, 12);
            this.label8.TabIndex = 0;
            this.label8.Text = "用户名：";
            // 
            // pan_Oracle
            // 
            this.pan_Oracle.Controls.Add(this.groupBox1);
            this.pan_Oracle.Location = new System.Drawing.Point(35, 71);
            this.pan_Oracle.Name = "pan_Oracle";
            this.pan_Oracle.Size = new System.Drawing.Size(373, 188);
            this.pan_Oracle.TabIndex = 13;
            this.pan_Oracle.Visible = false;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.btn_CheckOraConn);
            this.groupBox1.Controls.Add(this.txt_serviceName);
            this.groupBox1.Controls.Add(this.txt_password);
            this.groupBox1.Controls.Add(this.txt_UserName);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Location = new System.Drawing.Point(3, 3);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(367, 183);
            this.groupBox1.TabIndex = 1;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "建立Oracle数据库连接";
            // 
            // btn_CheckOraConn
            // 
            this.btn_CheckOraConn.Location = new System.Drawing.Point(264, 150);
            this.btn_CheckOraConn.Name = "btn_CheckOraConn";
            this.btn_CheckOraConn.Size = new System.Drawing.Size(75, 23);
            this.btn_CheckOraConn.TabIndex = 16;
            this.btn_CheckOraConn.Text = "测试连接";
            this.btn_CheckOraConn.UseVisualStyleBackColor = true;
            this.btn_CheckOraConn.Click += new System.EventHandler(this.btn_CheckOraConn_Click);
            // 
            // txt_serviceName
            // 
            this.txt_serviceName.Location = new System.Drawing.Point(99, 34);
            this.txt_serviceName.Name = "txt_serviceName";
            this.txt_serviceName.Size = new System.Drawing.Size(239, 21);
            this.txt_serviceName.TabIndex = 6;
            // 
            // txt_password
            // 
            this.txt_password.Location = new System.Drawing.Point(99, 112);
            this.txt_password.Name = "txt_password";
            this.txt_password.Size = new System.Drawing.Size(239, 21);
            this.txt_password.TabIndex = 8;
            // 
            // txt_UserName
            // 
            this.txt_UserName.Location = new System.Drawing.Point(100, 74);
            this.txt_UserName.Name = "txt_UserName";
            this.txt_UserName.Size = new System.Drawing.Size(239, 21);
            this.txt_UserName.TabIndex = 7;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(41, 37);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(53, 12);
            this.label3.TabIndex = 2;
            this.label3.Text = "服务名：";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(41, 115);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(53, 12);
            this.label2.TabIndex = 1;
            this.label2.Text = "密  码：";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(41, 77);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(53, 12);
            this.label1.TabIndex = 0;
            this.label1.Text = "用户名：";
            // 
            // ConnectForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(442, 322);
            this.Controls.Add(this.pan_Oracle);
            this.Controls.Add(this.pan_Sql);
            this.Controls.Add(this.pan_MySql);
            this.Controls.Add(this.btn_Connect);
            this.Controls.Add(this.btn_close);
            this.Controls.Add(this.lbl_DBType);
            this.Controls.Add(this.cbx_DataBaseType);
            this.Name = "ConnectForm";
            this.Text = "连接数据库";
            this.Load += new System.EventHandler(this.ConnectForm_Load);
            this.pan_Sql.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.pan_MySql.ResumeLayout(false);
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.pan_Oracle.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btn_close;
        private System.Windows.Forms.Button btn_Connect;
        private System.Windows.Forms.Label lbl_DBType;
        private System.Windows.Forms.ComboBox cbx_DataBaseType;
        private System.Windows.Forms.Panel pan_Sql;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button btn_SqlCheckConn;
        private System.Windows.Forms.TextBox txt_SqlPassWord;
        private System.Windows.Forms.TextBox txt_SqlDbName;
        private System.Windows.Forms.TextBox txt_SqlUserName;
        private System.Windows.Forms.TextBox txt_ServerAddr;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Panel pan_MySql;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Button btn_MySqlCheckConn;
        private System.Windows.Forms.TextBox txt_MySqlPassWord;
        private System.Windows.Forms.TextBox txt_MySqlDbName;
        private System.Windows.Forms.TextBox txt_MySqlUserName;
        private System.Windows.Forms.TextBox txt_MySqlAddr;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Panel pan_Oracle;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button btn_CheckOraConn;
        private System.Windows.Forms.TextBox txt_serviceName;
        private System.Windows.Forms.TextBox txt_password;
        private System.Windows.Forms.TextBox txt_UserName;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
    }
}